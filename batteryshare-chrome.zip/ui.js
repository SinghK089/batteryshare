// Shared popup pieces: device icons, rings, chips, time formats and the 24-hour chart.

// Simple line icons per device kind (the app's device families).
export const ICONS = {
  phone: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M11 18.5h2"/></svg>',
  foldable: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M3 5.5 11 4v16l-8-1.5z"/><path d="M21 5.5 13 4v16l8-1.5z"/></svg>',
  tablet: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="5" y="2.5" width="14" height="19" rx="2.5"/><path d="M11 18.5h2"/></svg>',
  watch: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="5.5"/><path d="M9 6.8 9.6 3h4.8l.6 3.8M9 17.2l.6 3.8h4.8l.6-3.8"/></svg>',
  laptop: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="4" y="5" width="16" height="11" rx="1.5"/><path d="M2 19h20"/></svg>',
  headphones: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 15v-3a8 8 0 0 1 16 0v3"/><rect x="3" y="14" width="4" height="6" rx="1.5"/><rect x="17" y="14" width="4" height="6" rx="1.5"/></svg>',
  earbuds: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="7" cy="7" r="3"/><path d="M8 10v10"/><circle cx="17" cy="7" r="3"/><path d="M16 10v10"/></svg>',
  speaker: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="6" y="3" width="12" height="18" rx="3"/><circle cx="12" cy="14" r="3"/><circle cx="12" cy="7.5" r="1"/></svg>',
  band: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="8" y="7" width="8" height="10" rx="2.5"/><path d="M10 7V3h4v4M10 17v4h4v-4"/></svg>',
};
export function iconFor(kind = "", type = "") {
  const k = String(kind).toUpperCase();
  if (k === "FOLDABLE") return ICONS.foldable;
  if (/TABLET|IPAD/.test(k) || type === "TABLET") return ICONS.tablet;
  if (/WATCH|WEAR/.test(k) || type === "WATCH") return ICONS.watch;
  if (/MACBOOK|WINDOWS|CHROMEBOOK/.test(k) || type === "LAPTOP") return ICONS.laptop;
  if (/HEADPHONE/.test(k)) return ICONS.headphones;
  if (/EARBUD/.test(k)) return ICONS.earbuds;
  if (/SPEAKER/.test(k)) return ICONS.speaker;
  if (/BAND/.test(k)) return ICONS.band;
  return ICONS.phone;
}

export const STALE_MS = 30 * 60 * 1000;

export function ago(ms) {
  const m = Math.round((Date.now() - ms) / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} h ago`;
  return `${Math.round(h / 24)} d ago`;
}
export function duration(min) {
  if (min == null) return null;
  const h = Math.floor(min / 60), m = min % 60;
  if (!h) return `${m} min`;
  return m ? `${h} hr ${m} min` : `${h} hr`;
}

/** Fills a ring + chip + subtitle the way the app does: green→blue normally, amber low, red critical, grey offline. */
export function paint(ringEl, chipEl, subEl, d) {
  const level = Math.max(0, Math.min(100, Math.round(d.level ?? 0)));
  const offline = d.offline;
  const charging = d.chargingState === "CHARGING";
  const full = d.chargingState === "FULL" || (charging && level >= 100);
  ringEl.style.setProperty("--p", level);
  ringEl.classList.toggle("muted", offline);
  let c1 = "var(--green)", c2 = "var(--blue)";
  if (offline) { c1 = "#6b7280"; c2 = "#6b7280"; }
  else if (!charging && !full && level <= 10) { c1 = "#ff7a7e"; c2 = "var(--red)"; }
  else if (!charging && !full && level <= 20) { c1 = "#ffd166"; c2 = "var(--amber)"; }
  ringEl.style.setProperty("--c1", c1);
  ringEl.style.setProperty("--c2", c2);
  ringEl.parentElement.querySelector(".label").textContent = `${level}%`;

  let chip = "Steady", tone = "";
  if (offline) { chip = "Offline"; tone = "grey"; }
  else if (full) { chip = "Fully charged"; tone = "green"; }
  else if (charging) { chip = "Charging"; tone = "green"; }
  else if (level <= 10) { chip = "Critical"; tone = "red"; }
  else if (level <= 20) { chip = "Low"; tone = "amber"; }
  chipEl.textContent = chip;
  chipEl.className = "chip " + tone;

  let sub = "";
  if (offline) sub = `Seen ${ago(d.updatedAt || 0)}`;
  else if (charging && d.minutesToFull) sub = `Full in ${duration(d.minutesToFull)}`;
  else if (!charging && d.minutesLeft) sub = `About ${duration(d.minutesLeft)} left`;
  subEl.textContent = sub;
}

/** Wraps a .ring in a container with a centred % label (the ring itself is masked). */
export function ringWrap(ring) {
  if (ring.parentElement.classList.contains("ring-wrap")) return;
  const wrap = document.createElement("div");
  wrap.className = "ring-wrap" + (ring.classList.contains("big") ? " big" : "");
  ring.replaceWith(wrap);
  wrap.appendChild(ring);
  ring.innerHTML = "";
  const label = document.createElement("span");
  label.className = "label";
  wrap.appendChild(label);
}

/** Level over the last 24 hours, with charging stretches shaded green. Gaps over 3 h break the line. */
export function drawChart(svg, samples) {
  const W = 300, Hh = 120, now = Date.now(), from = now - 24 * 3_600_000;
  const x = (t) => ((t - from) / (now - from)) * W;
  const y = (l) => Hh - 6 - (l / 100) * (Hh - 12);
  const pts = samples.filter((s) => s.time >= from - 3_600_000);
  let html = `<defs><linearGradient id="lg" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#3b82f6"/><stop offset="1" stop-color="#40dc73"/></linearGradient>
    <linearGradient id="fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#40dc73" stop-opacity=".22"/><stop offset="1" stop-color="#3b82f6" stop-opacity="0"/></linearGradient></defs>`;
  for (const l of [0, 50, 100]) {
    html += `<line x1="0" x2="${W}" y1="${y(l)}" y2="${y(l)}" stroke="rgba(255,255,255,.08)" stroke-dasharray="${l === 0 ? "" : "3 4"}"/>`;
    html += `<text x="${W}" y="${y(l) - 3}" text-anchor="end" fill="#9aa6b8" font-size="9">${l}%</text>`;
  }
  // Charging stretches.
  for (let i = 1; i < pts.length; i++) {
    const a = pts[i - 1], b = pts[i];
    if (a.charging && b.time - a.time <= 3 * 3_600_000) {
      const x1 = Math.max(0, x(a.time)), x2 = Math.min(W, x(b.time));
      if (x2 > x1) html += `<rect x="${x1}" y="0" width="${x2 - x1}" height="${Hh}" fill="rgba(64,220,115,.14)"/>`;
    }
  }
  // Line, in runs without long gaps.
  const runs = [];
  let run = [];
  for (const s of pts) {
    if (run.length && s.time - run[run.length - 1].time > 3 * 3_600_000) { runs.push(run); run = []; }
    run.push(s);
  }
  if (run.length) runs.push(run);
  for (const r of runs) {
    const xy = r.map((s) => [Math.max(0, Math.min(W, x(s.time))), y(s.level)]);
    if (xy.length === 1) {
      html += `<circle cx="${xy[0][0]}" cy="${xy[0][1]}" r="3.5" fill="url(#lg)"/>`;
      continue;
    }
    const d = xy.map(([a, b], i) => `${i ? "L" : "M"}${a.toFixed(1)},${b.toFixed(1)}`).join("");
    html += `<path d="${d}L${xy[xy.length - 1][0].toFixed(1)},${Hh}L${xy[0][0].toFixed(1)},${Hh}Z" fill="url(#fill)"/>`;
    html += `<path d="${d}" fill="none" stroke="url(#lg)" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>`;
  }
  const last = pts[pts.length - 1];
  if (last && runs.some((r) => r.length > 1)) html += `<circle cx="${Math.min(W, x(last.time))}" cy="${y(last.level)}" r="3.5" fill="#40dc73"/>`;
  if (pts.length < 2) html += `<text class="chart-empty" x="${W / 2}" y="${Hh / 2}" text-anchor="middle">Collecting readings…</text>`;
  svg.innerHTML = html;
}
