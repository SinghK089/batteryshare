// Reads this computer's battery (Battery Status API) and describes the computer.

export function platform() {
  const p = (navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || "";
  if (/mac/i.test(p)) return { kind: "MACBOOK", platform: "MACOS", noun: "MacBook" };
  if (/win/i.test(p)) return { kind: "WINDOWS", platform: "WINDOWS", noun: "Windows laptop" };
  if (/cros|chrome/i.test(p)) return { kind: "CHROMEBOOK", platform: "CHROME_OS", noun: "Chromebook" };
  return { kind: "WINDOWS", platform: "WINDOWS", noun: "Laptop" };
}

/** { level 0-100, charging, full, minutesLeft, minutesToFull, hasBattery } */
export async function read() {
  if (!navigator.getBattery) return { hasBattery: false };
  const b = await navigator.getBattery();
  const level = Math.round(b.level * 100);
  // A desktop (no battery) reports 100%, charging, ready now, never empty.
  const hasBattery = !(b.charging && b.level === 1 && b.chargingTime === 0 && b.dischargingTime === Infinity);
  const finite = (s) => (Number.isFinite(s) && s > 0 ? Math.round(s / 60) : null);
  return {
    hasBattery,
    level,
    charging: b.charging,
    full: b.charging && level >= 100,
    minutesLeft: b.charging ? null : finite(b.dischargingTime),
    minutesToFull: b.charging ? finite(b.chargingTime) : null,
  };
}

/** Calls back whenever the level or charging state changes. */
export async function watch(callback) {
  if (!navigator.getBattery) return;
  const b = await navigator.getBattery();
  for (const ev of ["levelchange", "chargingchange", "chargingtimechange", "dischargingtimechange"]) {
    b.addEventListener(ev, () => callback());
  }
}
