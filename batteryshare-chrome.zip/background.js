// Background worker:
// - keeps this laptop's battery up to date in BatteryShare (on every change, and every 5 minutes)
// - records a week of readings for every device on the account (insights)
// - posts alerts (low, full, charge limit, hot, unusual drain) and smart notifications
//   (charge before you leave, weekly summary)
// - Find My Device: rings this computer when another device asks (checked every 30 s)
import { publish, account, devices, getDoc } from "./cloud.js";
import { platform } from "./battery.js";
import { record } from "./insights.js";
import { process as checkAlerts, leaveNudge, weeklySummary, badge } from "./alerts.js";
import { checkCommands, listenForStop } from "./find.js";
import { getSettings } from "./settings.js";

const SYNC = "sync";
const COMMANDS = "commands";
const MORNING = "morning";
const WEEKLY = "weekly";
const LATE_MS = 2 * 3_600_000; // skip a timed notification if the computer was asleep this long past it

async function deviceId() {
  let { deviceId } = await chrome.storage.local.get("deviceId");
  if (!deviceId) {
    deviceId = "chrome-" + crypto.randomUUID();
    await chrome.storage.local.set({ deviceId });
  }
  return deviceId;
}

async function ensureOffscreen() {
  if (await chrome.offscreen.hasDocument?.()) return;
  try {
    await chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["BATTERY_STATUS"],
      justification: "Read this computer's battery level to share it with your other devices.",
    });
  } catch (e) {
    // Already open (race between events): fine.
  }
}

async function requestReading() {
  await ensureOffscreen();
  chrome.runtime.sendMessage({ type: "readBattery" }).catch(() => {});
}

/** Name shown everywhere: what the user set, else "<first name>'s MacBook". */
async function selfName(acc) {
  const { deviceName, profileName } = await chrome.storage.local.get(["deviceName", "profileName"]);
  const os = platform();
  const first = (profileName || acc?.firstName || "").split(" ")[0];
  return deviceName || (first ? `${first}'s ${os.noun}` : os.noun);
}

/** This computer as a device record (same fields the Android app writes). */
async function selfDevice(battery, acc) {
  const os = platform();
  const settings = await getSettings();
  return {
    name: await selfName(acc),
    type: "LAPTOP",
    platform: os.platform,
    kind: os.kind,
    level: battery.level,
    chargingState: battery.full ? "FULL" : battery.charging ? "CHARGING" : "NOT_CHARGING",
    health: "UNKNOWN",
    minutesLeft: battery.minutesLeft,
    minutesToFull: battery.minutesToFull,
    // RING: your phone can ring this computer (Find My Device).
    capabilities: settings.allowRing ? ["BATTERY", "RING"] : ["BATTERY"],
    updatedAt: Date.now(),
    relayedBy: null,
    source: "chrome",
  };
}

let lastSent = "";
async function upload(battery, force = false) {
  await chrome.storage.local.set({ battery: { ...battery, at: Date.now() } });
  if (!battery.hasBattery) return;
  const id = await deviceId();
  await record(id, Date.now(), battery.level, battery.charging);
  const acc = await account();
  const device = await selfDevice(battery, acc);
  await checkAlerts([{ ...device, id, self: true }]);
  if (!acc) return;
  // Skip identical writes within a minute (battery events can fire in bursts).
  const sig = JSON.stringify([device.level, device.chargingState, device.name, device.capabilities, Math.floor(Date.now() / 60000)]);
  if (sig === lastSent && !force) return;
  lastSent = sig;
  await publish(id, device);
}

/** The account's other devices: record readings and check alerts. */
async function syncOthers() {
  const list = await devices();
  if (!list) return null;
  const self = await deviceId();
  const others = list.filter((d) => d.id !== self && d.updatedAt && d.level != null);
  for (const d of others) {
    await record(d.id, d.updatedAt, d.level, d.chargingState === "CHARGING" || d.chargingState === "FULL");
  }
  await checkAlerts(others);
  return others;
}

/** Every device, including this computer, for the morning and weekly notifications. */
async function everything() {
  const others = (await syncOthers()) || [];
  const { battery, deviceId: id } = await chrome.storage.local.get(["battery", "deviceId"]);
  if (battery?.hasBattery) {
    others.unshift({ ...(await selfDevice(battery, await account())), id, self: true });
  }
  return others;
}

/** Pulls the profile name (set in the app) so this computer's default name uses it. */
async function refreshProfile() {
  const acc = await account();
  if (!acc) return;
  const user = await getDoc(`users/${acc.uid}`);
  if (!user) return;
  await chrome.storage.local.set({ profileName: user.profileName || "", profileAvatar: user.profileAvatar || "" });
}

// ---------- Timed notifications ----------
function nextAt(minuteOfDay, from = Date.now()) {
  const d = new Date(from);
  d.setHours(Math.floor(minuteOfDay / 60), minuteOfDay % 60, 0, 0);
  if (d.getTime() <= from) d.setDate(d.getDate() + 1);
  return d.getTime();
}
function nextSundayEvening(from = Date.now()) {
  const d = new Date(from);
  d.setHours(19, 0, 0, 0);
  while (d.getDay() !== 0 || d.getTime() <= from) d.setDate(d.getDate() + 1);
  return d.getTime();
}
async function scheduleTimed() {
  const s = await getSettings();
  await chrome.alarms.clear(MORNING);
  await chrome.alarms.clear(WEEKLY);
  if (s.leaveNudge) {
    const when = nextAt(s.morningMinute);
    await chrome.storage.local.set({ morningAt: when });
    chrome.alarms.create(MORNING, { when });
  }
  if (s.weeklySummary) {
    const when = nextSundayEvening();
    await chrome.storage.local.set({ weeklyAt: when });
    chrome.alarms.create(WEEKLY, { when });
  }
}

async function schedule() {
  await chrome.alarms.create(SYNC, { periodInMinutes: 5 });
  await chrome.alarms.create(COMMANDS, { periodInMinutes: 0.5 });
  await scheduleTimed();
}

chrome.alarms.onAlarm.addListener(async (a) => {
  if (a.name === SYNC) {
    requestReading();
    syncOthers().catch(() => {});
  } else if (a.name === COMMANDS) {
    if (await account()) checkCommands().catch(() => {});
  } else if (a.name === MORNING || a.name === WEEKLY) {
    const key = a.name === MORNING ? "morningAt" : "weeklyAt";
    const { [key]: due } = await chrome.storage.local.get(key);
    const onTime = !due || Date.now() - due < LATE_MS;
    if (onTime && (await account())) {
      const all = await everything().catch(() => []);
      if (a.name === MORNING) await leaveNudge(all);
      else await weeklySummary(all);
    }
    scheduleTimed();
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.type === "battery") upload(msg.battery);
  if (msg?.type === "syncNow") {
    requestReading();
    syncOthers().catch(() => {});
    refreshProfile().catch(() => {});
    reply?.({ ok: true });
  }
  if (msg?.type === "republish") {
    chrome.storage.local.get("battery").then(({ battery }) => battery && upload(battery, true));
  }
  if (msg?.type === "settingsChanged") {
    scheduleTimed();
    chrome.storage.local.get("battery").then(({ battery }) => battery && upload(battery, true));
  }
  if (msg?.type === "signedIn") {
    refreshProfile().then(() => chrome.storage.local.get("battery")).then(({ battery }) => battery && upload(battery, true));
    syncOthers().catch(() => {});
  }
  if (msg?.type === "deviceId") { deviceId().then((id) => reply({ id })); return true; }
});

// Clicking an alert opens the popup (where Chrome allows it).
chrome.notifications.onClicked.addListener((id) => {
  if (id.startsWith("bs-") && id !== "bs-ring") {
    chrome.notifications.clear(id);
    chrome.action.openPopup?.().catch(() => {});
  }
});
listenForStop();

async function start() {
  await schedule();
  requestReading();
  syncOthers().catch(() => {});
  refreshProfile().catch(() => {});
  badge().catch(() => {});
}
chrome.runtime.onInstalled.addListener(start);
chrome.runtime.onStartup.addListener(start);
