// Keeps this laptop's battery up to date in BatteryShare: on every battery change, and every
// 5 minutes while Chrome is open (the phone shows it as offline when the laptop sleeps).
import { publish, account, devices } from "./cloud.js";
import { platform } from "./battery.js";
import { record } from "./insights.js";

const ALARM = "sync";

async function deviceId() {
  let { deviceId } = await chrome.storage.local.get("deviceId");
  if (!deviceId) {
    deviceId = "chrome-" + crypto.randomUUID();
    await chrome.storage.local.set({ deviceId });
  }
  return deviceId;
}

async function ensureOffscreen() {
  if (await chrome.offscreen.hasDocument?.()) return;
  try {
    await chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["BATTERY_STATUS"],
      justification: "Read this computer's battery level to share it with your other devices.",
    });
  } catch (e) {
    // Already open (race between events): fine.
  }
}

async function requestReading() {
  await ensureOffscreen();
  chrome.runtime.sendMessage({ type: "readBattery" }).catch(() => {});
}

let lastSent = "";
async function upload(battery) {
  await chrome.storage.local.set({ battery: { ...battery, at: Date.now() } });
  if (battery.hasBattery) await record(await deviceId(), Date.now(), battery.level, battery.charging);
  const acc = await account();
  if (!acc || !battery.hasBattery) return;
  const { deviceName } = await chrome.storage.local.get("deviceName");
  const os = platform();
  const name = deviceName || (acc.firstName ? `${acc.firstName}'s ${os.noun}` : os.noun);
  const device = {
    name,
    type: "LAPTOP",
    platform: os.platform,
    kind: os.kind,
    level: battery.level,
    chargingState: battery.full ? "FULL" : battery.charging ? "CHARGING" : "NOT_CHARGING",
    health: "UNKNOWN",
    minutesLeft: battery.minutesLeft,
    minutesToFull: battery.minutesToFull,
    capabilities: ["BATTERY"],
    updatedAt: Date.now(),
    relayedBy: null,
    source: "chrome",
  };
  // Skip identical writes within a minute (battery events can fire in bursts).
  const sig = JSON.stringify([device.level, device.chargingState, device.name, Math.floor(Date.now() / 60000)]);
  if (sig === lastSent) return;
  lastSent = sig;
  await publish(await deviceId(), device);
}

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.type === "battery") upload(msg.battery);
  if (msg?.type === "syncNow") { requestReading(); recordOthers().catch(() => {}); reply?.({ ok: true }); }
  if (msg?.type === "deviceId") { deviceId().then((id) => reply({ id })); return true; }
});

/** Keeps a week of readings for the account's other devices, for their insights. */
async function recordOthers() {
  const list = await devices();
  if (!list) return;
  const self = await deviceId();
  for (const d of list) {
    if (d.id === self || !d.updatedAt || d.level == null) continue;
    await record(d.id, d.updatedAt, d.level, d.chargingState === "CHARGING" || d.chargingState === "FULL");
  }
}

chrome.alarms.onAlarm.addListener((a) => {
  if (a.name !== ALARM) return;
  requestReading();
  recordOthers().catch(() => {});
});

async function start() {
  await chrome.alarms.create(ALARM, { periodInMinutes: 5 });
  requestReading();
  recordOthers().catch(() => {});
}
chrome.runtime.onInstalled.addListener(start);
chrome.runtime.onStartup.addListener(start);
