// Alerts and smart notifications, the same rules as the app's AlertCenter and InsightAlarms.
// Events are kept for 7 days (chrome.storage.local "events") for the Notifications screen.
import { getSettings } from "./settings.js";
import { proStatus } from "./pro.js";
import { history, drain, weekly } from "./insights.js";

const LOW = 20, CRITICAL = 10, HOT_C = 42, HOT_CLEAR_C = 39;
const STALE_MS = 30 * 60_000;
const UNUSUAL_COOLDOWN_MS = 6 * 3_600_000;
const NUDGE_GAP_MS = 4 * 3_600_000;
const LOW_FOR_LEAVING = 50;
const KEEP_MS = 7 * 86_400_000;

const NOUN = {
  PHONE: "phone", FOLDABLE: "phone", TABLET: "tablet", IPAD: "tablet", WATCH: "watch", LAPTOP: "laptop",
  MACBOOK: "MacBook", WINDOWS: "laptop", CHROMEBOOK: "Chromebook", HEADPHONES: "headphones",
  EARBUDS: "earbuds", SPEAKER: "speaker", BAND: "band",
};
export function noun(d) {
  const k = String(d.kind || "").toUpperCase();
  for (const [key, n] of Object.entries(NOUN)) if (k.includes(key)) return n;
  return String(d.type || "").toUpperCase() === "WATCH" ? "watch" : "device";
}
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);

const TITLES = {
  LOW: () => "Battery running low",
  CRITICAL: () => "Battery critically low",
  CHARGING: () => "Charging started",
  FULL: () => "Battery fully charged",
  CHARGE_LIMIT: (e) => `${cap(e.noun)} at ${e.level}%, unplug now`,
  HOT: () => "Hot while charging",
  UNUSUAL_DRAIN: () => "Draining faster than usual",
};
const DETAILS = {
  LOW: (e) => `${e.level}% remaining · Plug in soon`,
  CRITICAL: (e) => `${e.level}% remaining · Charge now`,
  CHARGING: (e) => `${e.level}% · Your ${e.noun} is charging`,
  FULL: () => "100% · Ready to unplug",
  CHARGE_LIMIT: () => "Charge limit reached · Stopping here helps the battery last longer",
  HOT: () => "Unplug and let it cool down",
  UNUSUAL_DRAIN: (e) => `${e.level}% left · Check for an app using the battery`,
};

// ---------- Event list ----------
export async function events() {
  const { events = [] } = await chrome.storage.local.get("events");
  const from = Date.now() - KEEP_MS;
  return events.filter((e) => e.time >= from);
}
async function saveEvents(list) {
  await chrome.storage.local.set({ events: list.slice(0, 200) });
  await badge();
}
export async function markAllRead() {
  await saveEvents((await events()).map((e) => ({ ...e, read: true })));
}
export async function removeEvent(id) {
  await saveEvents((await events()).filter((e) => e.id !== id));
}
export async function clearEvents() {
  await saveEvents([]);
}
/** Unread count on the toolbar icon. */
export async function badge() {
  const n = (await events()).filter((e) => !e.read).length;
  await chrome.action.setBadgeText({ text: n ? String(Math.min(n, 99)) : "" });
  await chrome.action.setBadgeBackgroundColor({ color: "#24bff3" });
}

let lock = Promise.resolve();
const serial = (fn) => (lock = lock.then(fn).catch(() => {}));

async function post(list, settings, urgentTypes = ["CRITICAL", "HOT", "LEAVE"]) {
  if (!list.length) return;
  const all = await events();
  await saveEvents([...list.slice().reverse(), ...all]);
  for (const e of list) {
    chrome.notifications.create(`bs-${e.id}`, {
      type: "basic",
      iconUrl: "icons/128.png",
      title: e.device && !e.report ? `${e.title} · ${e.device}` : e.title,
      message: e.detail || "",
      silent: !settings.sound,
      priority: urgentTypes.includes(e.type) ? 2 : 0,
    });
  }
}

// ---------- Per-reading alerts ----------
/**
 * Compares each device with its last reading and posts what changed.
 * devices: [{ id, name, kind, type, level, chargingState, temperatureC, updatedAt, self }]
 */
export function process(devices) {
  return serial(async () => {
    const settings = await getSettings();
    const { alertState: state = {} } = await chrome.storage.local.get("alertState");
    const now = Date.now();
    let pro = null;
    const isPro = async () => (pro ??= (await proStatus()).pro);
    const out = [];

    for (const d of devices) {
      if (d.level == null) continue;
      const charging = d.chargingState === "CHARGING" || d.chargingState === "FULL";
      const full = d.chargingState === "FULL" || (d.chargingState === "CHARGING" && d.level >= 100);
      const fresh = d.self || (d.updatedAt && now - d.updatedAt < STALE_MS);
      const prev = state[d.id];
      const accessory = String(d.type).toUpperCase() === "ACCESSORY";
      const add = (type, note) => {
        const e = { id: now + out.length, type, deviceId: d.id, device: d.name || "Device", noun: noun(d), level: d.level, time: now, read: false };
        e.title = TITLES[type](e);
        e.detail = note || DETAILS[type](e);
        out.push(e);
      };

      if (prev && fresh) {
        if (settings.fullAlerts && !accessory) {
          if (full && !prev.full) add("FULL");
          else if (charging && !prev.charging) add("CHARGING");
        }
        const limit = settings.chargeLimit;
        if (settings.chargeLimitAlerts && d.chargingState === "CHARGING" && d.level >= limit && prev.level < limit && d.level < 100 && (await isPro())) {
          add("CHARGE_LIMIT");
        }
        const t = d.temperatureC;
        if (settings.hotAlerts && charging && t != null && t >= HOT_C && !prev.hot && (await isPro())) {
          add("HOT", `${Math.round(t)}°C · Unplug and let it cool down`);
        }
        if (settings.unusualDrain && !charging && now - (prev.drainAlertAt || 0) > UNUSUAL_COOLDOWN_MS) {
          const dr = drain(await history(d.id), now);
          if (dr.unusual && (await isPro())) {
            add("UNUSUAL_DRAIN", `Using ${Math.round(dr.recent)}% an hour · usually ${Math.max(1, Math.round(dr.usual))}%`);
            prev.drainAlertAt = now;
          }
        }
        if (settings.lowAlerts && !settings.mutedLow.includes(d.id) && !charging) {
          if (d.level <= CRITICAL && prev.level > CRITICAL) add("CRITICAL");
          else if (d.level <= LOW && prev.level > LOW) add("LOW");
        }
      }

      const t = d.temperatureC;
      const wasHot = prev?.hot || false;
      const hot = charging && t != null && (t >= HOT_C || (wasHot && t >= HOT_CLEAR_C));
      state[d.id] = {
        level: fresh ? d.level : prev?.level ?? d.level,
        charging,
        full,
        hot: fresh ? hot : wasHot,
        drainAlertAt: prev?.drainAlertAt || 0,
      };
    }
    await chrome.storage.local.set({ alertState: state });
    await post(out, settings);
  });
}

// ---------- Smart notifications (Pro) ----------
/** Morning: devices below 50% that aren't charging. */
export function leaveNudge(devices) {
  return serial(async () => {
    const settings = await getSettings();
    if (!settings.leaveNudge || !(await proStatus()).pro) return;
    const { lastNudge = 0 } = await chrome.storage.local.get("lastNudge");
    const now = Date.now();
    if (now - lastNudge < NUDGE_GAP_MS) return;
    const low = devices
      .filter((d) => d.level != null && (d.self || now - (d.updatedAt || 0) < 3 * 3_600_000))
      .filter((d) => d.chargingState !== "CHARGING" && d.chargingState !== "FULL" && d.level < LOW_FOR_LEAVING)
      .sort((a, b) => a.level - b.level);
    if (!low.length) return;
    await chrome.storage.local.set({ lastNudge: now });
    await post([{
      id: now, type: "LEAVE", report: true, device: "All devices", time: now, read: false,
      title: "Charge before you leave",
      detail: low.map((d) => `${d.name} ${d.level}%`).join(" · "),
    }], settings);
  });
}

/** Sunday evening: each device's week. */
export function weeklySummary(devices) {
  return serial(async () => {
    const settings = await getSettings();
    if (!settings.weeklySummary || !(await proStatus()).pro) return;
    const lines = [];
    for (const d of devices) {
      const wk = weekly(await history(d.id));
      if (!wk) continue;
      const parts = [];
      if (wk.perDay != null) parts.push(`~${wk.perDay}% a day`);
      if (wk.charges > 0 && String(d.type).toUpperCase() !== "ACCESSORY") parts.push(`${wk.charges} charge${wk.charges === 1 ? "" : "s"}`);
      if (wk.lowest <= 20) parts.push(`dipped to ${wk.lowest}%`);
      if (parts.length) lines.push(`${d.name}: ${parts.join(", ")}`);
    }
    if (!lines.length) return;
    const now = Date.now();
    await post([{ id: now, type: "WEEKLY", report: true, device: "All devices", time: now, read: false, title: "Your week in battery", detail: lines.join(" · ") }], settings);
  });
}

/** A one-off entry (Find My Device). */
export function note(type, title, detail, device) {
  return serial(async () => {
    const settings = await getSettings();
    const now = Date.now();
    const all = await events();
    await saveEvents([{ id: now, type, device, title, detail, time: now, read: false, report: true }, ...all]);
    void settings;
  });
}
