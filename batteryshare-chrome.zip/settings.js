// Settings for this computer (kept in chrome.storage.local, like the app keeps its own).
export const DEFAULTS = {
  lowAlerts: true, // 20% and 10%, every device
  fullAlerts: true, // fully charged and charging started
  chargeLimitAlerts: false, // Pro: "Phone at 80%, unplug now"
  chargeLimit: 80,
  hotAlerts: true, // Pro: hot while charging
  unusualDrain: true, // Pro: much faster than its usual
  sound: true, // notification sound (silent when off)
  leaveNudge: true, // Pro: morning "Charge before you leave"
  morningMinute: 7 * 60 + 30,
  weeklySummary: true, // Pro: Sunday evening
  allowRing: true, // Find My Device: let your other devices ring this computer
  mutedLow: [], // device IDs with low battery alerts off
};

export async function getSettings() {
  const { settings = {} } = await chrome.storage.local.get("settings");
  return { ...DEFAULTS, ...settings };
}

export async function setSettings(patch) {
  const next = { ...(await getSettings()), ...patch };
  await chrome.storage.local.set({ settings: next });
  chrome.runtime.sendMessage({ type: "settingsChanged" }).catch(() => {});
  return next;
}
