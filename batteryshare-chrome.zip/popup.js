import { signIn, signOut, account, devices } from "./cloud.js";
import { read, platform } from "./battery.js";

const $ = (id) => document.getElementById(id);
const show = (id, on) => $(id).classList.toggle("hidden", !on);

// Simple line icons per device kind (the app's device families).
const ICONS = {
  phone: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M11 18.5h2"/></svg>',
  foldable: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M3 5.5 11 4v16l-8-1.5z"/><path d="M21 5.5 13 4v16l8-1.5z"/></svg>',
  tablet: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="5" y="2.5" width="14" height="19" rx="2.5"/><path d="M11 18.5h2"/></svg>',
  watch: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="5.5"/><path d="M9 6.8 9.6 3h4.8l.6 3.8M9 17.2l.6 3.8h4.8l.6-3.8"/></svg>',
  laptop: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="4" y="5" width="16" height="11" rx="1.5"/><path d="M2 19h20"/></svg>',
  headphones: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 15v-3a8 8 0 0 1 16 0v3"/><rect x="3" y="14" width="4" height="6" rx="1.5"/><rect x="17" y="14" width="4" height="6" rx="1.5"/></svg>',
  earbuds: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="7" cy="7" r="3"/><path d="M8 10v10"/><circle cx="17" cy="7" r="3"/><path d="M16 10v10"/></svg>',
  speaker: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="6" y="3" width="12" height="18" rx="3"/><circle cx="12" cy="14" r="3"/><circle cx="12" cy="7.5" r="1"/></svg>',
  band: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="8" y="7" width="8" height="10" rx="2.5"/><path d="M10 7V3h4v4M10 17v4h4v-4"/></svg>',
};
function iconFor(kind = "", type = "") {
  const k = String(kind).toUpperCase();
  if (k === "FOLDABLE") return ICONS.foldable;
  if (/TABLET|IPAD/.test(k) || type === "TABLET") return ICONS.tablet;
  if (/WATCH|WEAR/.test(k) || type === "WATCH") return ICONS.watch;
  if (/MACBOOK|WINDOWS|CHROMEBOOK/.test(k) || type === "LAPTOP") return ICONS.laptop;
  if (/HEADPHONE/.test(k)) return ICONS.headphones;
  if (/EARBUD/.test(k)) return ICONS.earbuds;
  if (/SPEAKER/.test(k)) return ICONS.speaker;
  if (/BAND/.test(k)) return ICONS.band;
  return ICONS.phone;
}

const STALE_MS = 30 * 60 * 1000;

function ago(ms) {
  const m = Math.round((Date.now() - ms) / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} h ago`;
  return `${Math.round(h / 24)} d ago`;
}
function duration(min) {
  if (min == null) return null;
  const h = Math.floor(min / 60), m = min % 60;
  if (!h) return `${m} min`;
  return m ? `${h} hr ${m} min` : `${h} hr`;
}

/** Fills a ring + chip + subtitle the way the app does: green→blue normally, amber low, red critical, grey offline. */
function paint(ringEl, chipEl, subEl, d) {
  const level = Math.max(0, Math.min(100, Math.round(d.level ?? 0)));
  const offline = d.offline;
  const charging = d.chargingState === "CHARGING";
  const full = d.chargingState === "FULL" || (charging && level >= 100);
  ringEl.style.setProperty("--p", level);
  ringEl.classList.toggle("muted", offline);
  let c1 = "var(--green)", c2 = "var(--blue)";
  if (offline) { c1 = "#6b7280"; c2 = "#6b7280"; }
  else if (!charging && !full && level <= 10) { c1 = "#ff7a7e"; c2 = "var(--red)"; }
  else if (!charging && !full && level <= 20) { c1 = "#ffd166"; c2 = "var(--amber)"; }
  ringEl.style.setProperty("--c1", c1);
  ringEl.style.setProperty("--c2", c2);
  ringEl.parentElement.querySelector(".label").textContent = `${level}%`;

  let chip = "Steady", tone = "";
  if (offline) { chip = "Offline"; tone = "grey"; }
  else if (full) { chip = "Fully charged"; tone = "green"; }
  else if (charging) { chip = "Charging"; tone = "green"; }
  else if (level <= 10) { chip = "Critical"; tone = "red"; }
  else if (level <= 20) { chip = "Low"; tone = "amber"; }
  chipEl.textContent = chip;
  chipEl.className = "chip " + tone;

  let sub = "";
  if (offline) sub = `Seen ${ago(d.updatedAt || 0)}`;
  else if (charging && d.minutesToFull) sub = `Full in ${duration(d.minutesToFull)}`;
  else if (!charging && d.minutesLeft) sub = `About ${duration(d.minutesLeft)} left`;
  subEl.textContent = sub;
}

/** Wraps a .ring in a container with a centred % label (the ring itself is masked). */
function ringWrap(ring) {
  if (ring.parentElement.classList.contains("ring-wrap")) return;
  const wrap = document.createElement("div");
  wrap.className = "ring-wrap" + (ring.classList.contains("big") ? " big" : "");
  ring.replaceWith(wrap);
  wrap.appendChild(ring);
  ring.innerHTML = "";
  const label = document.createElement("span");
  label.className = "label";
  wrap.appendChild(label);
}

async function renderSelf(acc) {
  const os = platform();
  const b = await read();
  const { deviceName } = await chrome.storage.local.get("deviceName");
  $("selfName").textContent = deviceName || (acc?.firstName ? `${acc.firstName}'s ${os.noun}` : `This ${os.noun}`);
  $("selfIcon").innerHTML = ICONS.laptop;
  ringWrap($("selfRing"));
  if (!b.hasBattery) {
    $("selfRing").style.setProperty("--p", 0);
    $("selfRing").parentElement.querySelector(".label").textContent = "—";
    $("selfChip").textContent = "No battery";
    $("selfChip").className = "chip grey";
    $("selfSub").textContent = "This computer doesn't have a battery to share.";
    $("selfDot").classList.add("off");
    return;
  }
  paint($("selfRing"), $("selfChip"), $("selfSub"), {
    level: b.level,
    chargingState: b.full ? "FULL" : b.charging ? "CHARGING" : "NOT_CHARGING",
    minutesLeft: b.minutesLeft,
    minutesToFull: b.minutesToFull,
  });
}

async function renderOthers() {
  const list = await devices();
  const { deviceId } = await chrome.storage.local.get("deviceId");
  const grid = $("grid");
  grid.innerHTML = "";
  if (!list) { $("sync").textContent = "Couldn't reach BatteryShare. Check your connection."; return; }
  const others = list
    .filter((d) => d.id !== deviceId)
    .map((d) => ({ ...d, offline: !d.updatedAt || Date.now() - d.updatedAt > STALE_MS }))
    .sort((a, b) => (a.offline - b.offline) || (b.updatedAt || 0) - (a.updatedAt || 0));
  show("empty", others.length === 0);
  const tpl = $("cardTpl");
  for (const d of others) {
    const node = tpl.content.firstElementChild.cloneNode(true);
    node.querySelector(".dev-icon").innerHTML = iconFor(d.kind, d.type);
    node.querySelector(".title").textContent = d.name || "Device";
    node.querySelector(".dot").classList.toggle("off", d.offline);
    const ring = node.querySelector(".ring");
    grid.appendChild(node);
    ringWrap(ring);
    paint(ring, node.querySelector(".chip"), node.querySelector(".sub"), d);
  }
  $("sync").textContent = "Synced " + new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}

async function render() {
  const acc = await account();
  show("out", !acc);
  show("in", !!acc);
  show("menuBtn", !!acc);
  if (!acc) {
    ringWrap($("outRing"));
    const b = await read();
    paint($("outRing"), document.createElement("span"), document.createElement("p"), {
      level: b.hasBattery ? b.level : 0,
      chargingState: b.charging ? "CHARGING" : "NOT_CHARGING",
    });
    if (!b.hasBattery) $("outRing").parentElement.querySelector(".label").textContent = "—";
    return;
  }
  const btn = $("menuBtn");
  if (acc.photo) { btn.style.backgroundImage = `url("${acc.photo}")`; btn.textContent = ""; }
  else btn.textContent = (acc.firstName || acc.email || "?").slice(0, 1).toUpperCase();
  $("menuEmail").textContent = acc.email;
  await renderSelf(acc);
  chrome.runtime.sendMessage({ type: "syncNow" }).catch(() => {});
  await renderOthers();
}

$("signIn").addEventListener("click", async () => {
  $("signIn").disabled = true;
  show("signInErr", false);
  try {
    await signIn();
    await render();
  } catch (e) {
    const msg = String(e && e.message || e);
    if (!/did not approve|closed|cancel/i.test(msg)) {
      $("signInErr").textContent = "Couldn't sign in: " + msg;
      show("signInErr", true);
    }
  } finally {
    $("signIn").disabled = false;
  }
});

$("menuBtn").addEventListener("click", (e) => { e.stopPropagation(); $("menu").classList.toggle("hidden"); });
document.addEventListener("click", () => $("menu").classList.add("hidden"));
$("signOut").addEventListener("click", async () => { await signOut(); $("menu").classList.add("hidden"); render(); });
$("rename").addEventListener("click", async () => {
  const current = $("selfName").textContent;
  const name = prompt("Name for this computer", current);
  if (name && name.trim()) {
    await chrome.storage.local.set({ deviceName: name.trim().slice(0, 40) });
    chrome.runtime.sendMessage({ type: "syncNow" }).catch(() => {});
    render();
  }
});

render();
