import { signIn, signInWithEmail, signOut, account, devices, getDoc, patchDoc, remove } from "./cloud.js";
import { read, platform } from "./battery.js";
import { history, drain, sessions, weekly, summary, forget } from "./insights.js";
import { ICONS, iconFor, STALE_MS, ago, duration, paint, ringWrap, drawChart } from "./ui.js";
import { events, markAllRead, removeEvent, clearEvents, badge } from "./alerts.js";
import { getSettings, setSettings } from "./settings.js";
import { proStatus, proLabel } from "./pro.js";
import { ring, stop as stopRing, status as ringStatus, RING_MS } from "./find.js";

const $ = (id) => document.getElementById(id);
const show = (id, on) => $(id).classList.toggle("hidden", !on);

// ---------- Avatars (the app's set; keys never change) ----------
const AVATAR_LABELS = [
  "Young man with curly hair", "Young man with glasses", "Young man in a cap with headphones", "Young man with a beard",
  "Young man in a turban", "Young man with orange glasses", "Young man in a blue shirt", "Older man with a moustache",
  "Young woman with earrings", "Young woman with glasses and a book", "Young woman waving", "Young woman with wavy hair",
  "Young woman with headphones", "Young woman with a flower braid", "Young woman in sunglasses", "Older woman",
  "Kid in a cap", "Kid with a teddy bear", "Kid with glasses", "Kid with a flower clip", "Kid with a football",
  "Kid with pigtails", "Teen with earphones", "Teen with long hair", "Professional with a laptop",
  "Professional with glasses", "Doctor", "Police officer", "Chef", "Teacher with glasses", "Rider in a helmet",
  "Delivery partner", "Farmer",
];
const AVATARS = AVATAR_LABELS.map((label, i) => ({ key: `clay_${String(i + 1).padStart(2, "0")}`, label }));
const avatarUrl = (key) => (AVATARS.some((a) => a.key === key) ? `avatars/${key}.webp` : null);

/** Fills an element with the avatar, the Google photo, or an initial. */
function fillAvatar(el, profile, acc) {
  const url = avatarUrl(profile.avatar) || acc?.photo || "";
  el.style.backgroundImage = url ? `url("${url}")` : "";
  el.textContent = url ? "" : (profile.name || acc?.email || "?").slice(0, 1).toUpperCase();
}

// ---------- State ----------
const state = { acc: null, profile: { name: "", avatar: "" }, pro: { pro: false }, self: null, others: [], view: "home", openId: null };

// ---------- Views ----------
const VIEWS = ["out", "home", "detail", "alerts", "settings", "profile"];
const TITLES = { home: "BatteryShare", detail: "BatteryShare", alerts: "Notifications", settings: "Settings", profile: "Profile" };
function go(view) {
  state.view = view;
  for (const v of VIEWS) show(`v-${v}`, v === view);
  show("backBtn", !["home", "out"].includes(view));
  $("brand").textContent = TITLES[view] || "BatteryShare";
  $("menu").classList.add("hidden");
  document.documentElement.scrollTop = 0;
  document.body.scrollTop = 0;
  if (view === "detail") renderDetail();
  if (view === "alerts") renderAlerts();
  if (view === "settings") renderSettings();
  if (view === "profile") renderProfile();
}
function back() {
  if (state.view === "detail" || state.view === "alerts" || state.view === "settings" || state.view === "profile") {
    state.openId = null;
    stopWatchingRing();
    go("home");
  }
}

// ---------- Home ----------
async function renderSelf() {
  const os = platform();
  const b = await read();
  const { deviceName, deviceId } = await chrome.storage.local.get(["deviceName", "deviceId"]);
  const first = (state.profile.name || state.acc?.firstName || "").split(" ")[0];
  const name = deviceName || (first ? `${first}'s ${os.noun}` : `This ${os.noun}`);
  $("selfName").textContent = name;
  $("selfIcon").innerHTML = ICONS.laptop;
  ringWrap($("selfRing"));
  state.self = null;
  if (!b.hasBattery) {
    $("selfRing").style.setProperty("--p", 0);
    $("selfRing").parentElement.querySelector(".label").textContent = "—";
    $("selfChip").textContent = "No battery";
    $("selfChip").className = "chip grey";
    $("selfSub").textContent = "This computer doesn't have a battery to share.";
    $("selfDot").classList.add("off");
    return;
  }
  state.self = {
    id: deviceId, self: true, name, type: "LAPTOP", kind: os.kind, level: b.level,
    chargingState: b.full ? "FULL" : b.charging ? "CHARGING" : "NOT_CHARGING",
    minutesLeft: b.minutesLeft, minutesToFull: b.minutesToFull, health: "UNKNOWN", updatedAt: Date.now(),
  };
  paint($("selfRing"), $("selfChip"), $("selfSub"), state.self);
}

async function renderOthers() {
  const list = await devices();
  const { deviceId } = await chrome.storage.local.get("deviceId");
  const grid = $("grid");
  if (!list) { $("sync").textContent = "Couldn't reach BatteryShare. Check your connection."; return; }
  grid.innerHTML = "";
  const others = list
    .filter((d) => d.id !== deviceId)
    .map((d) => ({ ...d, offline: !d.updatedAt || Date.now() - d.updatedAt > STALE_MS }))
    .sort((a, b) => (a.offline - b.offline) || (b.updatedAt || 0) - (a.updatedAt || 0));
  state.others = others;
  show("empty", others.length === 0);
  const tpl = $("cardTpl");
  for (const d of others) {
    const node = tpl.content.firstElementChild.cloneNode(true);
    node.querySelector(".dev-icon").innerHTML = iconFor(d.kind, d.type);
    node.querySelector(".title").textContent = d.name || "Device";
    node.querySelector(".dot").classList.toggle("off", d.offline);
    node.setAttribute("aria-label", `${d.name || "Device"} details`);
    const open = () => { state.openId = d.id; go("detail"); };
    node.addEventListener("click", open);
    node.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); open(); } });
    const r = node.querySelector(".ring");
    grid.appendChild(node);
    ringWrap(r);
    paint(r, node.querySelector(".chip"), node.querySelector(".sub"), d);
  }
  $("sync").textContent = "Synced " + new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  if (state.view === "detail") renderDetail();
}

function greeting() {
  const h = new Date().getHours();
  const part = h < 5 ? "Good night" : h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening";
  const first = (state.profile.name || state.acc?.firstName || "").split(" ")[0];
  return first ? `${part}, ${first}` : part;
}

async function renderBell() {
  const n = (await events()).filter((e) => !e.read).length;
  $("bellCount").textContent = n > 9 ? "9+" : String(n);
  show("bellCount", n > 0);
}

async function loadProfile() {
  const cached = await chrome.storage.local.get(["profileName", "profileAvatar"]);
  state.profile = { name: cached.profileName || state.acc?.name || "", avatar: cached.profileAvatar || "" };
  const user = await getDoc(`users/${state.acc.uid}`);
  if (user) {
    state.profile = { name: user.profileName || state.acc?.name || "", avatar: user.profileAvatar || "" };
    await chrome.storage.local.set({ profileName: user.profileName || "", profileAvatar: user.profileAvatar || "" });
  }
}

function renderHeader() {
  fillAvatar($("menuBtn"), state.profile, state.acc);
  fillAvatar($("menuAvatar"), state.profile, state.acc);
  $("menuName").textContent = state.profile.name || "BatteryShare";
  $("menuEmail").textContent = state.acc.email || "";
  $("menuPlan").textContent = proLabel(state.pro);
  $("menuPlan").classList.toggle("is-pro", !!state.pro.pro);
  $("greet").textContent = greeting();
}

async function render() {
  state.acc = await account();
  show("menuBtn", !!state.acc);
  show("bellBtn", !!state.acc);
  if (!state.acc) {
    go("out");
    ringWrap($("outRing"));
    const b = await read();
    paint($("outRing"), document.createElement("span"), document.createElement("p"), {
      level: b.hasBattery ? b.level : 0,
      chargingState: b.charging ? "CHARGING" : "NOT_CHARGING",
    });
    if (!b.hasBattery) $("outRing").parentElement.querySelector(".label").textContent = "—";
    return;
  }
  if (state.view === "out") state.view = "home";
  const cached = await chrome.storage.local.get(["profileName", "profileAvatar"]);
  state.profile = { name: cached.profileName || state.acc.name || "", avatar: cached.profileAvatar || "" };
  renderHeader();
  go(state.view);
  await renderSelf();
  renderBell();
  chrome.runtime.sendMessage({ type: "syncNow" }).catch(() => {});
  await Promise.all([
    renderOthers(),
    loadProfile().then(renderHeader).then(renderSelf),
    proStatus().then((p) => { state.pro = p; renderHeader(); }),
  ]);
}

// ---------- Device detail ----------
const HEALTH = { GOOD: ["Good", "green"], OVERHEATING: ["Overheating", "red"], NEEDS_SERVICE: ["Needs service", "amber"] };
const isAccessory = (d) => d.type === "ACCESSORY" || /HEADPHONE|EARBUD|SPEAKER|BAND/.test(String(d.kind || "").toUpperCase());
const perHour = (x) => (x == null ? "—" : `${x}%/h`);
const fmtTime = (ms) => new Date(ms).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
function fmtDay(ms) {
  const d = new Date(ms), today = new Date();
  const y = new Date(); y.setDate(today.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return "Today";
  if (d.toDateString() === y.toDateString()) return "Yesterday";
  return d.toLocaleDateString([], { weekday: "short", day: "numeric", month: "short" });
}
const current = () => (state.openId && state.openId === state.self?.id ? state.self : state.others.find((x) => x.id === state.openId));

async function renderDetail() {
  const d = current();
  if (!d) { back(); return; }
  const accessory = isAccessory(d);
  const charging = d.chargingState === "CHARGING";
  const full = d.chargingState === "FULL";
  const reportsTime = !accessory && (d.self || full || d.minutesLeft != null || d.minutesToFull != null);

  $("dIcon").innerHTML = d.self ? ICONS.laptop : iconFor(d.kind, d.type);
  $("dName").textContent = d.name || "Device";
  $("dDot").classList.toggle("off", !!d.offline);
  ringWrap($("dRing"));
  paint($("dRing"), $("dChip"), $("dSub"), d);

  // Find My Device: devices that can ring (phones, tablets, watches, other laptops).
  const canRing = !d.self && Array.isArray(d.capabilities) && d.capabilities.includes("RING");
  show("dFind", canRing);
  if (canRing && !ringWatch) setFind("idle", d);

  const samples = await history(d.id);
  if (d.level != null && d.updatedAt && (!samples.length || d.updatedAt > samples[samples.length - 1].time)) {
    samples.push({ time: d.updatedAt, level: d.level, charging: charging || full });
  }
  const dr = drain(samples);
  const sum = summary(d.level ?? 0, dr);
  if (d.offline) {
    $("dHeadline").textContent = `Last seen ${ago(d.updatedAt || 0)}`;
    $("dCompare").textContent = "Insights update when it's back online";
    $("dCompare").className = "compare";
  } else if (charging || full) {
    $("dHeadline").textContent = full ? "Fully charged" : d.minutesToFull ? `Full in ${duration(d.minutesToFull)}` : "Charging";
    $("dCompare").textContent = d.chargeWatts ? `Charging at ${Math.round(d.chargeWatts)} W` : dr.usual != null ? `Usually uses ${dr.usual}% an hour` : "Learning its usual pace";
    $("dCompare").className = "compare green";
  } else {
    // The device's own estimate wins, so the headline matches the line under the ring.
    $("dHeadline").textContent = !accessory && d.minutesLeft ? `About ${duration(d.minutesLeft)} left` : sum.headline;
    $("dCompare").textContent = sum.compare;
    $("dCompare").className = "compare " + sum.tone;
  }

  drawChart($("dChart"), samples);

  const wk = weekly(samples);
  const tiles = [];
  tiles.push(["Using now", perHour(dr.recent), dr.unusual ? "red" : ""]);
  tiles.push(["Usually", perHour(dr.usual), ""]);
  if (wk?.perDay != null) tiles.push(["Per day (7 days)", `${wk.perDay}%`, ""]);
  if (wk && !accessory) tiles.push(["Charges (7 days)", String(wk.charges), ""]);
  if (wk) tiles.push(["Lowest (7 days)", `${wk.lowest}%`, wk.lowest <= 10 ? "red" : wk.lowest <= 20 ? "amber" : ""]);
  if (wk?.avgChargeMinutes != null && !accessory) tiles.push(["Average charge", duration(wk.avgChargeMinutes), ""]);
  if (reportsTime && !d.offline) {
    if (charging && d.minutesToFull) tiles.push(["Full in", duration(d.minutesToFull), "green"]);
    else if (!charging && !full && d.minutesLeft) tiles.push(["Time left", duration(d.minutesLeft), ""]);
  }
  if (HEALTH[d.health]) tiles.push(["Battery health", HEALTH[d.health][0], HEALTH[d.health][1]]);
  if (d.temperatureC != null) tiles.push(["Temperature", `${Math.round(d.temperatureC)}°C`, d.temperatureC >= 42 ? "red" : ""]);
  if (charging && d.chargeWatts) tiles.push(["Charging power", `${Math.round(d.chargeWatts)} W`, "green"]);
  tiles.push(["Updated", d.self ? "Just now" : ago(d.updatedAt || 0), ""]);
  const box = $("dTiles");
  box.innerHTML = "";
  for (const [k, v, tone] of tiles) {
    const t = document.createElement("div");
    t.className = "tile";
    t.innerHTML = `<div class="k"></div><div class="v ${tone}"></div>`;
    t.querySelector(".k").textContent = k;
    t.querySelector(".v").textContent = v;
    box.appendChild(t);
  }

  const list = accessory ? [] : sessions(samples).slice(0, 6);
  show("dChargesBox", !accessory);
  const ch = $("dCharges");
  ch.innerHTML = "";
  if (!accessory) {
    if (!list.length) ch.innerHTML = '<p class="muted small" style="margin:10px 0">No charges recorded yet.</p>';
    for (const x of list) {
      const row = document.createElement("div");
      row.className = "item";
      row.innerHTML = '<span class="bolt"><svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M13 2 4 14h7l-1 8 9-12h-7z"/></svg></span><div class="main"><b></b><span></span></div><span class="dur"></span>';
      row.querySelector("b").textContent = `${x.startLevel}% → ${x.endLevel}%`;
      row.querySelector(".main span").textContent = x.open ? `${fmtDay(x.start)}, since ${fmtTime(x.start)} · charging now` : `${fmtDay(x.start)}, ${fmtTime(x.start)}–${fmtTime(x.end)}`;
      row.querySelector(".dur").textContent = x.minutes ? duration(x.minutes) : "";
      ch.appendChild(row);
    }
  }

  const settings = await getSettings();
  $("dLowAlert").checked = settings.lowAlerts && !settings.mutedLow.includes(d.id);
  $("dLowAlert").disabled = !settings.lowAlerts;

  const days = wk?.days ?? 0;
  $("dNote").textContent = days < 1
    ? "Insights build up while Chrome is open on this computer. The usual pace needs about a day of readings."
    : `Based on ${days >= 6.5 ? "the past week" : `${Math.max(1, Math.round(days))} day${Math.round(days) === 1 ? "" : "s"}`} of readings collected on this computer.`;
}

$("dLowAlert").addEventListener("change", async (e) => {
  const d = current();
  if (!d) return;
  const s = await getSettings();
  const muted = new Set(s.mutedLow);
  if (e.target.checked) muted.delete(d.id); else muted.add(d.id);
  await setSettings({ mutedLow: [...muted] });
});

// Ringing another device.
let ringWatch = null; // { id, timer, started }
function setFind(mode, d = current()) {
  const btn = $("dRingBtn"), note = $("dFindNote");
  const noun = d ? (d.name || "this device") : "this device";
  btn.disabled = false;
  btn.classList.toggle("active", mode === "ringing" || mode === "sending");
  switch (mode) {
    case "sending": note.textContent = `Calling ${noun}…`; btn.textContent = "Stop"; break;
    case "ringing": note.textContent = `Ringing ${noun} now`; btn.textContent = "Stop"; break;
    case "stopped": note.textContent = "Stopped"; btn.textContent = "Ring again"; break;
    case "failed": note.textContent = "It didn't answer. It may be off or offline."; btn.textContent = "Try again"; break;
    case "error": note.textContent = "Couldn't send the request. Check your connection."; btn.textContent = "Try again"; break;
    default:
      note.textContent = d?.offline ? "It looks offline, so it may not ring" : "Play a sound for 45 seconds";
      btn.textContent = "Ring";
  }
}
function stopWatchingRing() {
  if (ringWatch) clearInterval(ringWatch.timer);
  ringWatch = null;
}
$("dRingBtn").addEventListener("click", async () => {
  const d = current();
  if (!d) return;
  if (ringWatch) {
    const id = ringWatch.id;
    stopWatchingRing();
    $("dRingBtn").disabled = true;
    await stopRing(id);
    setFind("stopped", d);
    return;
  }
  setFind("sending", d);
  const id = await ring(d.id);
  if (!id) { setFind("error", d); return; }
  ringWatch = { id, started: Date.now(), timer: null };
  ringWatch.timer = setInterval(async () => {
    if (!ringWatch || ringWatch.id !== id) return;
    const s = await ringStatus(id);
    const age = Date.now() - ringWatch.started;
    if (s === "ringing") setFind("ringing", d);
    if (s === "stopped" || (s === "ringing" && age > RING_MS + 5000)) { stopWatchingRing(); setFind("stopped", d); }
    if (s === "failed" || (s === "pending" && age > 60_000)) { stopWatchingRing(); setFind("failed", d); }
  }, 2000);
});

// ---------- Notifications ----------
const ALERT_TONE = { LOW: "amber", CRITICAL: "red", CHARGING: "green", FULL: "green", CHARGE_LIMIT: "green", HOT: "red", UNUSUAL_DRAIN: "red", LEAVE: "amber", WEEKLY: "blue", RING: "blue" };
const ALERT_ICON = {
  LOW: '<path d="M7 7h9a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1z"/><path d="M19 10v4"/><path d="M8.5 14.5v-5"/>',
  CRITICAL: '<path d="M7 7h9a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1z"/><path d="M19 10v4"/><path d="M11.5 9.5v3M11.5 14.5v.01"/>',
  CHARGING: '<path d="M13 3 6 13h5l-1 8 7-10h-5z"/>',
  FULL: '<path d="M7 7h9a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1z"/><path d="M19 10v4"/><path d="M9 12l2 2 3-4"/>',
  CHARGE_LIMIT: '<path d="M12 3v9"/><path d="M7 7a7 7 0 1 0 10 0"/>',
  HOT: '<path d="M10 14V5a2 2 0 1 1 4 0v9a4 4 0 1 1-4 0z"/>',
  UNUSUAL_DRAIN: '<path d="M4 7l6 6 4-4 6 6"/><path d="M20 11v4h-4"/>',
  LEAVE: '<path d="M12 7v5l3 2"/><circle cx="12" cy="12" r="8"/>',
  WEEKLY: '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M9 3v4M15 3v4"/>',
  RING: '<path d="M11 5 6 9H3v6h3l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/>',
};
async function renderAlerts() {
  const list = await events();
  const box = $("alertList");
  box.innerHTML = "";
  show("alertsEmpty", list.length === 0);
  show("clearAll", list.length > 0);
  let lastDay = "";
  for (const e of list) {
    const day = fmtDay(e.time);
    if (day !== lastDay) {
      const h = document.createElement("p");
      h.className = "day";
      h.textContent = day;
      box.appendChild(h);
      lastDay = day;
    }
    const row = document.createElement("div");
    row.className = "card alert" + (e.read ? "" : " unread");
    row.innerHTML = `<span class="a-icon ${ALERT_TONE[e.type] || ""}"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${ALERT_ICON[e.type] || ALERT_ICON.LEAVE}</svg></span>
      <div class="a-main"><div class="a-top"><b></b><span class="a-time"></span></div><span class="a-device"></span><p class="a-detail"></p></div>
      <button class="a-x" title="Remove" aria-label="Remove">×</button>`;
    row.querySelector("b").textContent = e.title;
    row.querySelector(".a-time").textContent = fmtTime(e.time);
    row.querySelector(".a-device").textContent = e.device || "";
    row.querySelector(".a-detail").textContent = e.detail || "";
    row.querySelector(".a-detail").classList.add(ALERT_TONE[e.type] || "");
    row.querySelector(".a-x").addEventListener("click", async () => { await removeEvent(e.id); renderAlerts(); });
    box.appendChild(row);
  }
  if (list.some((e) => !e.read)) { await markAllRead(); renderBell(); }
}
$("clearAll").addEventListener("click", async () => { await clearEvents(); renderAlerts(); renderBell(); });

// ---------- Settings ----------
async function renderSettings() {
  const s = await getSettings();
  const pro = !!state.pro.pro;
  document.querySelectorAll("#v-settings .switch[data-k]").forEach((el) => {
    const locked = el.closest(".srow")?.classList.contains("pro") && !pro;
    el.checked = !!s[el.dataset.k] && !locked;
    el.disabled = locked;
    el.closest(".srow").classList.toggle("locked", locked);
  });
  const sel = $("limitSel");
  if (!sel.options.length) for (let v = 50; v <= 95; v += 5) sel.add(new Option(`${v}%`, v));
  sel.value = String(s.chargeLimit);
  sel.disabled = !pro;
  const m = s.morningMinute;
  $("morningTime").value = `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
  $("morningTime").disabled = !pro;
  show("proNote", !pro);
  const { deviceName } = await chrome.storage.local.get("deviceName");
  $("nameInput").value = deviceName || "";
  $("nameInput").placeholder = $("selfName").textContent || "This computer";
  $("accEmail").textContent = state.acc?.email || "";
  $("accPlan").textContent = proLabel(state.pro);
  $("ver").textContent = chrome.runtime.getManifest().version;
  $("removeBtn").textContent = "Remove";
  $("removeBtn").dataset.armed = "";
}
document.querySelectorAll("#v-settings .switch[data-k]").forEach((el) => {
  el.addEventListener("change", () => setSettings({ [el.dataset.k]: el.checked }));
});
$("limitSel").addEventListener("change", (e) => setSettings({ chargeLimit: Number(e.target.value) }));
$("morningTime").addEventListener("change", (e) => {
  const [h, m] = e.target.value.split(":").map(Number);
  if (Number.isFinite(h) && Number.isFinite(m)) setSettings({ morningMinute: h * 60 + m });
});

$("nameSave").addEventListener("click", async () => {
  const name = $("nameInput").value.trim().slice(0, 40);
  if (name) await chrome.storage.local.set({ deviceName: name });
  else await chrome.storage.local.remove("deviceName");
  chrome.runtime.sendMessage({ type: "republish" }).catch(() => {});
  $("nameSave").textContent = "Saved";
  setTimeout(() => ($("nameSave").textContent = "Save"), 1500);
  renderSelf();
});
$("removeBtn").addEventListener("click", async () => {
  const btn = $("removeBtn");
  if (!btn.dataset.armed) { btn.dataset.armed = "1"; btn.textContent = "Tap to confirm"; return; }
  btn.disabled = true;
  const { deviceId } = await chrome.storage.local.get("deviceId");
  if (deviceId) { await remove(deviceId); await forget(deviceId); }
  await signOut();
  btn.disabled = false;
  render();
});

// ---------- Profile ----------
let pickedAvatar = "";
function renderProfile() {
  pickedAvatar = state.profile.avatar || "";
  $("pName").value = state.profile.name || "";
  $("pEmail").textContent = state.acc?.email || "";
  fillAvatar($("pAvatar"), { name: state.profile.name, avatar: pickedAvatar }, state.acc);
  const grid = $("avatarGrid");
  if (!grid.children.length) {
    for (const a of AVATARS) {
      const b = document.createElement("button");
      b.className = "av";
      b.type = "button";
      b.setAttribute("role", "radio");
      b.setAttribute("aria-label", a.label);
      b.title = a.label;
      b.dataset.key = a.key;
      b.style.backgroundImage = `url("avatars/${a.key}.webp")`;
      b.addEventListener("click", () => {
        pickedAvatar = a.key;
        markAvatar();
        fillAvatar($("pAvatar"), { name: $("pName").value, avatar: pickedAvatar }, state.acc);
      });
      grid.appendChild(b);
    }
  }
  markAvatar();
}
function markAvatar() {
  document.querySelectorAll("#avatarGrid .av").forEach((b) => {
    const on = b.dataset.key === pickedAvatar;
    b.classList.toggle("on", on);
    b.setAttribute("aria-checked", on ? "true" : "false");
  });
}
$("pSave").addEventListener("click", async () => {
  const name = $("pName").value.trim().replace(/\s+/g, " ").slice(0, 30);
  $("pSave").disabled = true;
  const ok = await patchDoc(`users/${state.acc.uid}`, { profileName: name, profileAvatar: pickedAvatar || null });
  $("pSave").disabled = false;
  if (!ok) { $("pSave").textContent = "Couldn't save. Try again"; return; }
  state.profile = { name, avatar: pickedAvatar };
  await chrome.storage.local.set({ profileName: name, profileAvatar: pickedAvatar });
  chrome.runtime.sendMessage({ type: "republish" }).catch(() => {});
  renderHeader();
  renderSelf();
  $("pSave").textContent = "Save";
  back();
});

// ---------- Header, menu, keys ----------
$("backBtn").addEventListener("click", back);
$("bellBtn").addEventListener("click", () => go(state.view === "alerts" ? "home" : "alerts"));
$("menuBtn").addEventListener("click", (e) => { e.stopPropagation(); $("menu").classList.toggle("hidden"); });
document.addEventListener("click", (e) => { if (!$("menu").contains(e.target)) $("menu").classList.add("hidden"); });
$("goProfile").addEventListener("click", () => go("profile"));
$("goSettings").addEventListener("click", () => go("settings"));
const doSignOut = async () => { await signOut(); $("menu").classList.add("hidden"); state.view = "home"; render(); };
$("signOut").addEventListener("click", doSignOut);
$("signOut2").addEventListener("click", doSignOut);
document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  if (!$("menu").classList.contains("hidden")) { $("menu").classList.add("hidden"); return; }
  if (!["home", "out"].includes(state.view)) { e.preventDefault(); back(); }
});
const openSelf = () => { if (state.self) { state.openId = state.self.id; go("detail"); } };
$("selfCard").addEventListener("click", openSelf);
$("selfCard").addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openSelf(); } });
chrome.storage.onChanged.addListener((c) => { if (c.events) { renderBell(); if (state.view === "alerts") renderAlerts(); } });

// ---------- Sign in ----------
async function afterSignIn() {
  chrome.runtime.sendMessage({ type: "signedIn" }).catch(() => {});
  await chrome.storage.local.remove("proCache");
  state.view = "home";
  await render();
}
$("emailToggle").addEventListener("click", () => {
  const open = $("emailForm").classList.toggle("hidden") === false;
  $("emailToggle").textContent = open ? "Hide email sign-in" : "Sign in with email";
  if (open) $("email").focus();
});
$("emailForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("emailSignIn").disabled = true;
  show("emailErr", false);
  try {
    await signInWithEmail($("email").value, $("password").value);
    $("password").value = "";
    await afterSignIn();
  } catch (err) {
    $("emailErr").textContent = String(err?.message || err);
    show("emailErr", true);
  } finally {
    $("emailSignIn").disabled = false;
  }
});
$("signIn").addEventListener("click", async () => {
  $("signIn").disabled = true;
  show("signInErr", false);
  try {
    await signIn();
    await afterSignIn();
  } catch (e) {
    const msg = String((e && e.message) || e);
    if (!/did not approve|closed|cancel/i.test(msg)) {
      $("signInErr").textContent = /only works in/.test(msg) ? msg : "Couldn't sign in: " + msg;
      show("signInErr", true);
    }
  } finally {
    $("signIn").disabled = false;
  }
});

badge().catch(() => {});
render();
