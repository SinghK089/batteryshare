import { signIn, signInWithEmail, signOut, account, devices } from "./cloud.js";
import { read, platform } from "./battery.js";
import { history, drain, sessions, weekly, summary } from "./insights.js";

const $ = (id) => document.getElementById(id);
const show = (id, on) => $(id).classList.toggle("hidden", !on);

// Simple line icons per device kind (the app's device families).
const ICONS = {
  phone: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M11 18.5h2"/></svg>',
  foldable: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M3 5.5 11 4v16l-8-1.5z"/><path d="M21 5.5 13 4v16l8-1.5z"/></svg>',
  tablet: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="5" y="2.5" width="14" height="19" rx="2.5"/><path d="M11 18.5h2"/></svg>',
  watch: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="5.5"/><path d="M9 6.8 9.6 3h4.8l.6 3.8M9 17.2l.6 3.8h4.8l.6-3.8"/></svg>',
  laptop: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="4" y="5" width="16" height="11" rx="1.5"/><path d="M2 19h20"/></svg>',
  headphones: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 15v-3a8 8 0 0 1 16 0v3"/><rect x="3" y="14" width="4" height="6" rx="1.5"/><rect x="17" y="14" width="4" height="6" rx="1.5"/></svg>',
  earbuds: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="7" cy="7" r="3"/><path d="M8 10v10"/><circle cx="17" cy="7" r="3"/><path d="M16 10v10"/></svg>',
  speaker: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="6" y="3" width="12" height="18" rx="3"/><circle cx="12" cy="14" r="3"/><circle cx="12" cy="7.5" r="1"/></svg>',
  band: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="8" y="7" width="8" height="10" rx="2.5"/><path d="M10 7V3h4v4M10 17v4h4v-4"/></svg>',
};
function iconFor(kind = "", type = "") {
  const k = String(kind).toUpperCase();
  if (k === "FOLDABLE") return ICONS.foldable;
  if (/TABLET|IPAD/.test(k) || type === "TABLET") return ICONS.tablet;
  if (/WATCH|WEAR/.test(k) || type === "WATCH") return ICONS.watch;
  if (/MACBOOK|WINDOWS|CHROMEBOOK/.test(k) || type === "LAPTOP") return ICONS.laptop;
  if (/HEADPHONE/.test(k)) return ICONS.headphones;
  if (/EARBUD/.test(k)) return ICONS.earbuds;
  if (/SPEAKER/.test(k)) return ICONS.speaker;
  if (/BAND/.test(k)) return ICONS.band;
  return ICONS.phone;
}

const STALE_MS = 30 * 60 * 1000;

function ago(ms) {
  const m = Math.round((Date.now() - ms) / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} h ago`;
  return `${Math.round(h / 24)} d ago`;
}
function duration(min) {
  if (min == null) return null;
  const h = Math.floor(min / 60), m = min % 60;
  if (!h) return `${m} min`;
  return m ? `${h} hr ${m} min` : `${h} hr`;
}

/** Fills a ring + chip + subtitle the way the app does: green→blue normally, amber low, red critical, grey offline. */
function paint(ringEl, chipEl, subEl, d) {
  const level = Math.max(0, Math.min(100, Math.round(d.level ?? 0)));
  const offline = d.offline;
  const charging = d.chargingState === "CHARGING";
  const full = d.chargingState === "FULL" || (charging && level >= 100);
  ringEl.style.setProperty("--p", level);
  ringEl.classList.toggle("muted", offline);
  let c1 = "var(--green)", c2 = "var(--blue)";
  if (offline) { c1 = "#6b7280"; c2 = "#6b7280"; }
  else if (!charging && !full && level <= 10) { c1 = "#ff7a7e"; c2 = "var(--red)"; }
  else if (!charging && !full && level <= 20) { c1 = "#ffd166"; c2 = "var(--amber)"; }
  ringEl.style.setProperty("--c1", c1);
  ringEl.style.setProperty("--c2", c2);
  ringEl.parentElement.querySelector(".label").textContent = `${level}%`;

  let chip = "Steady", tone = "";
  if (offline) { chip = "Offline"; tone = "grey"; }
  else if (full) { chip = "Fully charged"; tone = "green"; }
  else if (charging) { chip = "Charging"; tone = "green"; }
  else if (level <= 10) { chip = "Critical"; tone = "red"; }
  else if (level <= 20) { chip = "Low"; tone = "amber"; }
  chipEl.textContent = chip;
  chipEl.className = "chip " + tone;

  let sub = "";
  if (offline) sub = `Seen ${ago(d.updatedAt || 0)}`;
  else if (charging && d.minutesToFull) sub = `Full in ${duration(d.minutesToFull)}`;
  else if (!charging && d.minutesLeft) sub = `About ${duration(d.minutesLeft)} left`;
  subEl.textContent = sub;
}

/** Wraps a .ring in a container with a centred % label (the ring itself is masked). */
function ringWrap(ring) {
  if (ring.parentElement.classList.contains("ring-wrap")) return;
  const wrap = document.createElement("div");
  wrap.className = "ring-wrap" + (ring.classList.contains("big") ? " big" : "");
  ring.replaceWith(wrap);
  wrap.appendChild(ring);
  ring.innerHTML = "";
  const label = document.createElement("span");
  label.className = "label";
  wrap.appendChild(label);
}

async function renderSelf(acc) {
  const os = platform();
  const b = await read();
  const { deviceName } = await chrome.storage.local.get("deviceName");
  $("selfName").textContent = deviceName || (acc?.firstName ? `${acc.firstName}'s ${os.noun}` : `This ${os.noun}`);
  $("selfIcon").innerHTML = ICONS.laptop;
  ringWrap($("selfRing"));
  current.self = null;
  if (!b.hasBattery) {
    $("selfRing").style.setProperty("--p", 0);
    $("selfRing").parentElement.querySelector(".label").textContent = "—";
    $("selfChip").textContent = "No battery";
    $("selfChip").className = "chip grey";
    $("selfSub").textContent = "This computer doesn't have a battery to share.";
    $("selfDot").classList.add("off");
    return;
  }
  const self = {
    id: (await chrome.storage.local.get("deviceId")).deviceId,
    self: true,
    name: $("selfName").textContent,
    type: "LAPTOP",
    kind: os.kind,
    level: b.level,
    chargingState: b.full ? "FULL" : b.charging ? "CHARGING" : "NOT_CHARGING",
    minutesLeft: b.minutesLeft,
    minutesToFull: b.minutesToFull,
    health: "UNKNOWN",
    updatedAt: Date.now(),
  };
  current.self = self;
  paint($("selfRing"), $("selfChip"), $("selfSub"), self);
}

async function renderOthers() {
  const list = await devices();
  const { deviceId } = await chrome.storage.local.get("deviceId");
  const grid = $("grid");
  grid.innerHTML = "";
  if (!list) { $("sync").textContent = "Couldn't reach BatteryShare. Check your connection."; return; }
  const others = list
    .filter((d) => d.id !== deviceId)
    .map((d) => ({ ...d, offline: !d.updatedAt || Date.now() - d.updatedAt > STALE_MS }))
    .sort((a, b) => (a.offline - b.offline) || (b.updatedAt || 0) - (a.updatedAt || 0));
  current.others = others;
  show("empty", others.length === 0);
  const tpl = $("cardTpl");
  for (const d of others) {
    const node = tpl.content.firstElementChild.cloneNode(true);
    node.querySelector(".dev-icon").innerHTML = iconFor(d.kind, d.type);
    node.querySelector(".title").textContent = d.name || "Device";
    node.querySelector(".dot").classList.toggle("off", d.offline);
    const ring = node.querySelector(".ring");
    node.setAttribute("aria-label", `${d.name || "Device"} details`);
    node.addEventListener("click", () => openDetail(d.id));
    node.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openDetail(d.id); } });
    grid.appendChild(node);
    ringWrap(ring);
    paint(ring, node.querySelector(".chip"), node.querySelector(".sub"), d);
  }
  $("sync").textContent = "Synced " + new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  if (openId) renderDetail();
}

async function render() {
  const acc = await account();
  if (!acc) closeDetail();
  show("out", !acc);
  show("in", !!acc && !openId);
  show("menuBtn", !!acc);
  if (!acc) {
    ringWrap($("outRing"));
    const b = await read();
    paint($("outRing"), document.createElement("span"), document.createElement("p"), {
      level: b.hasBattery ? b.level : 0,
      chargingState: b.charging ? "CHARGING" : "NOT_CHARGING",
    });
    if (!b.hasBattery) $("outRing").parentElement.querySelector(".label").textContent = "—";
    return;
  }
  const btn = $("menuBtn");
  if (acc.photo) { btn.style.backgroundImage = `url("${acc.photo}")`; btn.textContent = ""; }
  else btn.textContent = (acc.firstName || acc.email || "?").slice(0, 1).toUpperCase();
  $("menuEmail").textContent = acc.email;
  await renderSelf(acc);
  chrome.runtime.sendMessage({ type: "syncNow" }).catch(() => {});
  await renderOthers();
}


// ---------- Device detail ----------

/** The devices on screen: this computer and the rest of the account. */
const current = { self: null, others: [] };
let openId = null;

const HEALTH = { GOOD: ["Good", "green"], OVERHEATING: ["Overheating", "red"], NEEDS_SERVICE: ["Needs service", "amber"] };
const isAccessory = (d) => d.type === "ACCESSORY" || /HEADPHONE|EARBUD|SPEAKER|BAND/.test(String(d.kind || "").toUpperCase());
const perHour = (x) => (x == null ? "—" : `${x}%/h`);
const fmtTime = (ms) => new Date(ms).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
function fmtDay(ms) {
  const d = new Date(ms), today = new Date();
  const y = new Date(); y.setDate(today.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return "Today";
  if (d.toDateString() === y.toDateString()) return "Yesterday";
  return d.toLocaleDateString([], { weekday: "short", day: "numeric", month: "short" });
}

function openDetail(id) {
  openId = id;
  show("in", false);
  show("detail", true);
  show("backBtn", true);
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
  renderDetail();
}
function closeDetail() {
  if (!openId) return;
  openId = null;
  show("detail", false);
  show("backBtn", false);
  show("in", true);
}

async function renderDetail() {
  const d = openId === current.self?.id ? current.self : current.others.find((x) => x.id === openId);
  if (!d) { closeDetail(); return; }
  const accessory = isAccessory(d);
  const charging = d.chargingState === "CHARGING";
  const full = d.chargingState === "FULL";
  const reportsTime = !accessory && (d.self || full || d.minutesLeft != null || d.minutesToFull != null);

  $("dIcon").innerHTML = d.self ? ICONS.laptop : iconFor(d.kind, d.type);
  $("dName").textContent = d.name || "Device";
  $("dDot").classList.toggle("off", !!d.offline);
  ringWrap($("dRing"));
  paint($("dRing"), $("dChip"), $("dSub"), d);

  const samples = await history(d.id);
  // Today's live reading counts too, so a fresh install still draws a point.
  if (d.level != null && d.updatedAt && (!samples.length || d.updatedAt > samples[samples.length - 1].time)) {
    samples.push({ time: d.updatedAt, level: d.level, charging: charging || full });
  }
  const dr = drain(samples);
  const sum = summary(d.level ?? 0, dr);
  if (d.offline) {
    $("dHeadline").textContent = `Last seen ${ago(d.updatedAt || 0)}`;
    $("dCompare").textContent = "Insights update when it's back online";
    $("dCompare").className = "compare";
  } else if (charging || full) {
    $("dHeadline").textContent = full ? "Fully charged" : d.minutesToFull ? `Full in ${duration(d.minutesToFull)}` : "Charging";
    $("dCompare").textContent = d.chargeWatts ? `Charging at ${Math.round(d.chargeWatts)} W` : dr.usual != null ? `Usually uses ${dr.usual}% an hour` : "Learning its usual pace";
    $("dCompare").className = "compare green";
  } else {
    // The device's own estimate wins, so the headline matches the line under the ring.
    $("dHeadline").textContent = !accessory && d.minutesLeft ? `About ${duration(d.minutesLeft)} left` : sum.headline;
    $("dCompare").textContent = sum.compare;
    $("dCompare").className = "compare " + sum.tone;
  }

  drawChart($("dChart"), samples);

  const wk = weekly(samples);
  const tiles = [];
  tiles.push(["Using now", perHour(dr.recent), dr.unusual ? "red" : ""]);
  tiles.push(["Usually", perHour(dr.usual), ""]);
  if (wk?.perDay != null) tiles.push(["Per day (7 days)", `${wk.perDay}%`, ""]);
  if (wk && !accessory) tiles.push(["Charges (7 days)", String(wk.charges), ""]);
  if (wk) tiles.push(["Lowest (7 days)", `${wk.lowest}%`, wk.lowest <= 10 ? "red" : wk.lowest <= 20 ? "amber" : ""]);
  if (wk?.avgChargeMinutes != null && !accessory) tiles.push(["Average charge", duration(wk.avgChargeMinutes), ""]);
  if (reportsTime && !d.offline) {
    if (charging && d.minutesToFull) tiles.push(["Full in", duration(d.minutesToFull), "green"]);
    else if (!charging && !full && d.minutesLeft) tiles.push(["Time left", duration(d.minutesLeft), ""]);
  }
  if (HEALTH[d.health]) tiles.push(["Battery health", HEALTH[d.health][0], HEALTH[d.health][1]]);
  if (d.temperatureC != null) tiles.push(["Temperature", `${Math.round(d.temperatureC)}°C`, d.temperatureC >= 42 ? "red" : ""]);
  if (charging && d.chargeWatts) tiles.push(["Charging power", `${Math.round(d.chargeWatts)} W`, "green"]);
  tiles.push(["Updated", d.self ? "Just now" : ago(d.updatedAt || 0), ""]);
  const box = $("dTiles");
  box.innerHTML = "";
  for (const [k, v, tone] of tiles) {
    const t = document.createElement("div");
    t.className = "tile";
    t.innerHTML = `<div class="k"></div><div class="v ${tone}"></div>`;
    t.querySelector(".k").textContent = k;
    t.querySelector(".v").textContent = v;
    box.appendChild(t);
  }

  const list = accessory ? [] : sessions(samples).slice(0, 6);
  show("dChargesBox", !accessory);
  const ch = $("dCharges");
  ch.innerHTML = "";
  if (!accessory) {
    if (!list.length) {
      ch.innerHTML = '<p class="muted small" style="margin:10px 0">No charges recorded yet.</p>';
    }
    for (const x of list) {
      const row = document.createElement("div");
      row.className = "item";
      row.innerHTML = '<span class="bolt"><svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M13 2 4 14h7l-1 8 9-12h-7z"/></svg></span><div class="main"><b></b><span></span></div><span class="dur"></span>';
      row.querySelector("b").textContent = `${x.startLevel}% → ${x.endLevel}%`;
      row.querySelector(".main span").textContent = x.open ? `${fmtDay(x.start)}, since ${fmtTime(x.start)} · charging now` : `${fmtDay(x.start)}, ${fmtTime(x.start)}–${fmtTime(x.end)}`;
      row.querySelector(".dur").textContent = x.minutes ? duration(x.minutes) : "";
      ch.appendChild(row);
    }
  }

  const days = wk?.days ?? 0;
  $("dNote").textContent = days < 1
    ? "Insights build up as this computer keeps Chrome open. Usual pace needs about a day of readings."
    : `Based on ${days >= 6.5 ? "the past week" : `${Math.max(1, Math.round(days))} day${Math.round(days) === 1 ? "" : "s"}`} of readings collected on this computer.`;
}

/** Level over the last 24 hours, with charging stretches shaded green. Gaps over 3 h break the line. */
function drawChart(svg, samples) {
  const W = 300, Hh = 120, now = Date.now(), from = now - 24 * 3_600_000;
  const x = (t) => ((t - from) / (now - from)) * W;
  const y = (l) => Hh - 6 - (l / 100) * (Hh - 12);
  const pts = samples.filter((s) => s.time >= from - 3_600_000);
  let html = `<defs><linearGradient id="lg" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#3b82f6"/><stop offset="1" stop-color="#40dc73"/></linearGradient>
    <linearGradient id="fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#40dc73" stop-opacity=".22"/><stop offset="1" stop-color="#3b82f6" stop-opacity="0"/></linearGradient></defs>`;
  for (const l of [0, 50, 100]) {
    html += `<line x1="0" x2="${W}" y1="${y(l)}" y2="${y(l)}" stroke="rgba(255,255,255,.08)" stroke-dasharray="${l === 0 ? "" : "3 4"}"/>`;
    html += `<text x="${W}" y="${y(l) - 3}" text-anchor="end" fill="#9aa6b8" font-size="9">${l}%</text>`;
  }
  // Charging stretches.
  for (let i = 1; i < pts.length; i++) {
    const a = pts[i - 1], b = pts[i];
    if (a.charging && b.time - a.time <= 3 * 3_600_000) {
      const x1 = Math.max(0, x(a.time)), x2 = Math.min(W, x(b.time));
      if (x2 > x1) html += `<rect x="${x1}" y="0" width="${x2 - x1}" height="${Hh}" fill="rgba(64,220,115,.14)"/>`;
    }
  }
  // Line, in runs without long gaps.
  const runs = [];
  let run = [];
  for (const s of pts) {
    if (run.length && s.time - run[run.length - 1].time > 3 * 3_600_000) { runs.push(run); run = []; }
    run.push(s);
  }
  if (run.length) runs.push(run);
  for (const r of runs) {
    const xy = r.map((s) => [Math.max(0, Math.min(W, x(s.time))), y(s.level)]);
    if (xy.length === 1) {
      html += `<circle cx="${xy[0][0]}" cy="${xy[0][1]}" r="3.5" fill="url(#lg)"/>`;
      continue;
    }
    const d = xy.map(([a, b], i) => `${i ? "L" : "M"}${a.toFixed(1)},${b.toFixed(1)}`).join("");
    html += `<path d="${d}L${xy[xy.length - 1][0].toFixed(1)},${Hh}L${xy[0][0].toFixed(1)},${Hh}Z" fill="url(#fill)"/>`;
    html += `<path d="${d}" fill="none" stroke="url(#lg)" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>`;
  }
  const last = pts[pts.length - 1];
  if (last && runs.some((r) => r.length > 1)) html += `<circle cx="${Math.min(W, x(last.time))}" cy="${y(last.level)}" r="3.5" fill="#40dc73"/>`;
  if (pts.length < 2) html += `<text class="chart-empty" x="${W / 2}" y="${Hh / 2}" text-anchor="middle">Collecting readings…</text>`;
  svg.innerHTML = html;
}

$("backBtn").addEventListener("click", closeDetail);
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && openId) { e.preventDefault(); closeDetail(); } });
$("selfCard").addEventListener("click", () => { if (current.self) openDetail(current.self.id); });
$("selfCard").addEventListener("keydown", (e) => { if ((e.key === "Enter" || e.key === " ") && current.self) { e.preventDefault(); openDetail(current.self.id); } });

// ---------- Email sign-in ----------
$("emailToggle").addEventListener("click", () => {
  const open = $("emailForm").classList.toggle("hidden") === false;
  $("emailToggle").textContent = open ? "Hide email sign-in" : "Sign in with email";
  if (open) $("email").focus();
});
$("emailForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("emailSignIn").disabled = true;
  show("emailErr", false);
  try {
    await signInWithEmail($("email").value, $("password").value);
    $("password").value = "";
    await render();
  } catch (err) {
    $("emailErr").textContent = String(err?.message || err);
    show("emailErr", true);
  } finally {
    $("emailSignIn").disabled = false;
  }
});

$("signIn").addEventListener("click", async () => {
  $("signIn").disabled = true;
  show("signInErr", false);
  try {
    await signIn();
    await render();
  } catch (e) {
    const msg = String(e && e.message || e);
    if (!/did not approve|closed|cancel/i.test(msg)) {
      $("signInErr").textContent = /only works in/.test(msg) ? msg : "Couldn't sign in: " + msg;
      show("signInErr", true);
    }
  } finally {
    $("signIn").disabled = false;
  }
});

$("menuBtn").addEventListener("click", (e) => { e.stopPropagation(); $("menu").classList.toggle("hidden"); });
document.addEventListener("click", () => $("menu").classList.add("hidden"));
$("signOut").addEventListener("click", async () => { await signOut(); $("menu").classList.add("hidden"); render(); });
$("rename").addEventListener("click", async () => {
  const current = $("selfName").textContent;
  const name = prompt("Name for this computer", current);
  if (name && name.trim()) {
    await chrome.storage.local.set({ deviceName: name.trim().slice(0, 40) });
    chrome.runtime.sendMessage({ type: "syncNow" }).catch(() => {});
    render();
  }
});

render();
