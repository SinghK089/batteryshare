// Google sign-in and Firestore over plain HTTPS (no SDK, nothing loaded from the web).
// Same Firebase project and data layout as the BatteryShare Android app:
//   users/{uid}/devices/{deviceId}

export const PROJECT = "batteryshare089-85b85";
const API_KEY = "AIzaSyD5vyzyNw6mduZik7a1M9PTTCA4VXlkB1M";
const WEB_CLIENT_ID = "390961017900-ntd8amhh2p8c5t0qgd02120h0gm9lcdb.apps.googleusercontent.com";
const FS = `https://firestore.googleapis.com/v1/projects/${PROJECT}/databases/(default)/documents`;

const get = (keys) => chrome.storage.local.get(keys);
const set = (obj) => chrome.storage.local.set(obj);

/** Opens Google's account picker, then signs in to Firebase with that account. */
// Extension IDs whose https://<id>.chromiumapp.org/ redirect is allowed on the OAuth client:
// the Chrome Web Store item and the website copy (manifest "key").
export const SIGN_IN_IDS = ["memjhklnddockibbedjdppeneflbmanb", "anhbnokkhflhibefmhljkbmalflkembk"];
export const googleSignInWorks = () => SIGN_IN_IDS.includes(chrome.runtime.id);

export async function signIn() {
  if (!googleSignInWorks()) {
    throw new Error(`Google sign-in only works in the Chrome Web Store version or the copy from the BatteryShare website. This copy's ID is ${chrome.runtime.id}. Use Sign in with email, or install it from the website.`);
  }
  const redirect = chrome.identity.getRedirectURL(); // https://<extension-id>.chromiumapp.org/
  const nonce = crypto.randomUUID();
  const url = "https://accounts.google.com/o/oauth2/v2/auth?" + new URLSearchParams({
    client_id: WEB_CLIENT_ID,
    response_type: "id_token",
    redirect_uri: redirect,
    scope: "openid email profile",
    nonce,
    prompt: "select_account",
  });
  const result = await chrome.identity.launchWebAuthFlow({ url, interactive: true });
  const idToken = new URLSearchParams(new URL(result).hash.slice(1)).get("id_token");
  if (!idToken) throw new Error("Google didn't return a sign-in token");

  const res = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithIdp?key=${API_KEY}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      postBody: `id_token=${idToken}&providerId=google.com`,
      requestUri: "http://localhost",
      returnSecureToken: true,
      returnIdpCredential: true,
    }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error?.message || "Sign-in failed");
  await set({
    account: {
      uid: data.localId,
      email: data.email,
      name: data.displayName || data.fullName || "",
      firstName: data.firstName || (data.displayName || "").split(" ")[0] || "",
      photo: data.photoUrl || "",
      idToken: data.idToken,
      refreshToken: data.refreshToken,
      expiresAt: Date.now() + (Number(data.expiresIn) - 60) * 1000,
    },
  });
  return (await get("account")).account;
}

/** Email and password sign-in (accounts created in Firebase, such as the store review account). */
export async function signInWithEmail(email, password) {
  const res = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${API_KEY}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email: String(email).trim(), password, returnSecureToken: true }),
  });
  const data = await res.json();
  if (!res.ok) {
    const code = data?.error?.message || "";
    if (/INVALID_LOGIN_CREDENTIALS|INVALID_PASSWORD|EMAIL_NOT_FOUND|INVALID_EMAIL/.test(code)) throw new Error("Wrong email or password");
    if (/TOO_MANY_ATTEMPTS/.test(code)) throw new Error("Too many attempts. Try again in a few minutes");
    if (/USER_DISABLED/.test(code)) throw new Error("This account is turned off");
    throw new Error(code || "Sign-in failed");
  }
  const name = data.displayName || "";
  await set({
    account: {
      uid: data.localId,
      email: data.email,
      name,
      firstName: name.split(" ")[0] || "",
      photo: "",
      idToken: data.idToken,
      refreshToken: data.refreshToken,
      expiresAt: Date.now() + (Number(data.expiresIn) - 60) * 1000,
    },
  });
  return (await get("account")).account;
}

export async function signOut() {
  await chrome.storage.local.remove(["account"]);
}

export async function account() {
  return (await get("account")).account || null;
}

/** A valid Firebase ID token, refreshed when it has expired. */
async function token() {
  const acc = await account();
  if (!acc) return null;
  if (Date.now() < acc.expiresAt) return acc;
  const res = await fetch(`https://securetoken.googleapis.com/v1/token?key=${API_KEY}`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "refresh_token", refresh_token: acc.refreshToken }),
  });
  const data = await res.json();
  if (!res.ok) {
    // Revoked or expired: sign in again.
    if (res.status === 400) await signOut();
    return null;
  }
  acc.idToken = data.id_token;
  acc.refreshToken = data.refresh_token;
  acc.expiresAt = Date.now() + (Number(data.expires_in) - 60) * 1000;
  await set({ account: acc });
  return acc;
}

// ---- Firestore value helpers ----
const v = (x) => {
  if (x === null || x === undefined) return { nullValue: null };
  if (typeof x === "boolean") return { booleanValue: x };
  if (typeof x === "number") return Number.isInteger(x) ? { integerValue: String(x) } : { doubleValue: x };
  if (Array.isArray(x)) return { arrayValue: { values: x.map(v) } };
  return { stringValue: String(x) };
};
const unv = (f) => {
  if (!f) return null;
  if ("stringValue" in f) return f.stringValue;
  if ("integerValue" in f) return Number(f.integerValue);
  if ("doubleValue" in f) return f.doubleValue;
  if ("booleanValue" in f) return f.booleanValue;
  if ("arrayValue" in f) return (f.arrayValue.values || []).map(unv);
  return null;
};

/** Writes this laptop, in the same shape the Android app writes its own record. */
export async function publish(id, device) {
  const acc = await token();
  if (!acc) return false;
  const fields = Object.fromEntries(Object.entries(device).map(([k, x]) => [k, v(x)]));
  const mask = Object.keys(device).map((k) => `updateMask.fieldPaths=${encodeURIComponent(k)}`).join("&");
  const res = await fetch(`${FS}/users/${acc.uid}/devices/${encodeURIComponent(id)}?${mask}`, {
    method: "PATCH",
    headers: { Authorization: `Bearer ${acc.idToken}`, "Content-Type": "application/json" },
    body: JSON.stringify({ fields }),
  });
  return res.ok;
}

/** Every device on this account (phone, watch, earbuds, other laptops…). */
export async function devices() {
  const acc = await token();
  if (!acc) return null;
  const res = await fetch(`${FS}/users/${acc.uid}/devices?pageSize=100`, {
    headers: { Authorization: `Bearer ${acc.idToken}` },
  });
  if (!res.ok) return null;
  const data = await res.json();
  return (data.documents || []).map((d) => {
    const out = { id: d.name.split("/").pop() };
    for (const [k, f] of Object.entries(d.fields || {})) out[k] = unv(f);
    return out;
  });
}

/** Removes this laptop from the account (Settings › Remove this computer). */
export async function remove(id) {
  const acc = await token();
  if (!acc) return false;
  const res = await fetch(`${FS}/users/${acc.uid}/devices/${encodeURIComponent(id)}`, {
    method: "DELETE",
    headers: { Authorization: `Bearer ${acc.idToken}` },
  });
  return res.ok;
}
