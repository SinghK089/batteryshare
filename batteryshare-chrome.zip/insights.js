// Battery history and insights, the same maths as the app's BatteryInsights.
// History is kept on this computer only (chrome.storage.local), up to a week per device:
//   hist = { [deviceId]: [[time, level, charging(0/1)], ...] }  oldest first

const H = 3_600_000;
export const RECENT_MS = 3 * H;
const WEEK_MS = 7 * 24 * H;
const MAX_GAP_MS = 3 * H;

const toSample = ([time, level, charging]) => ({ time, level, charging: !!charging });

/** Adds a reading if it is newer than the last one stored. Only the background worker writes. */
let queue = Promise.resolve();
export function record(id, time, level, charging) {
  queue = queue.then(() => add(id, time, level, charging)).catch(() => {});
  return queue;
}
async function add(id, time, level, charging) {
  if (!id || !Number.isFinite(level) || !time) return;
  const { hist = {} } = await chrome.storage.local.get("hist");
  const list = hist[id] || [];
  const last = list[list.length - 1];
  if (last && time <= last[0]) return;
  // Same reading again within 5 minutes: skip (battery events come in bursts).
  if (last && last[1] === level && last[2] === (charging ? 1 : 0) && time - last[0] < 5 * 60_000) return;
  list.push([time, Math.round(level), charging ? 1 : 0]);
  const from = Date.now() - WEEK_MS - H;
  hist[id] = list.filter((s) => s[0] >= from);
  // Drop devices with no readings in the last week.
  for (const k of Object.keys(hist)) if (!hist[k].length) delete hist[k];
  await chrome.storage.local.set({ hist });
}

export async function history(id) {
  const { hist = {} } = await chrome.storage.local.get("hist");
  return (hist[id] || []).map(toSample);
}

export async function forget(id) {
  const { hist = {} } = await chrome.storage.local.get("hist");
  delete hist[id];
  await chrome.storage.local.set({ hist });
}

/** Stretches between two readings while on battery. */
function discharge(samples, from, to) {
  const out = [];
  for (let i = 1; i < samples.length; i++) {
    const a = samples[i - 1], b = samples[i];
    if (a.charging || b.charging) continue;
    if (b.time - a.time > MAX_GAP_MS || b.time <= a.time) continue;
    if (a.time < from || b.time > to) continue;
    out.push({ hours: (b.time - a.time) / H, drop: Math.max(0, a.level - b.level) });
  }
  return out;
}

function rate(segments, minHours) {
  const hours = segments.reduce((s, x) => s + x.hours, 0);
  if (hours < minHours) return null;
  return segments.reduce((s, x) => s + x.drop, 0) / hours;
}
const r1 = (x) => (x == null ? null : Math.round(x * 10) / 10);

/** Percent per hour now (last 3 h) and usually (past week), and whether now is unusually fast. */
export function drain(samples, now = Date.now()) {
  const last = samples[samples.length - 1];
  const recent = last && now - last.time < H ? rate(discharge(samples, now - RECENT_MS, now), 1) : null;
  const usual = rate(discharge(samples, now - WEEK_MS, now - RECENT_MS), 12);
  const unusual = recent != null && usual != null && recent >= Math.max(usual * 2, usual + 4) && recent >= 5;
  return { recent: r1(recent), usual: r1(usual), unusual };
}

/** Time on the charger, newest first: { start, end, startLevel, endLevel, minutes, open }. */
export function sessions(samples) {
  const out = [];
  let cur = null;
  for (let i = 0; i < samples.length; i++) {
    const s = samples[i];
    const prev = samples[i - 1];
    if (cur && prev && s.time - prev.time > MAX_GAP_MS) { out.push(cur); cur = null; }
    if (s.charging) {
      if (!cur) cur = { start: s.time, end: s.time, startLevel: prev && !prev.charging && s.time - prev.time <= MAX_GAP_MS ? prev.level : s.level, endLevel: s.level };
      cur.end = s.time;
      cur.endLevel = Math.max(cur.endLevel, s.level);
    } else if (cur) {
      out.push(cur);
      cur = null;
    }
  }
  if (cur) out.push({ ...cur, open: true });
  return out
    .map((x) => ({ ...x, minutes: Math.round((x.end - x.start) / 60_000) }))
    .filter((x) => x.open || x.endLevel > x.startLevel || x.minutes >= 10)
    .reverse();
}

/** The past 7 days: average used per day, charges, average charge time, lowest level. */
export function weekly(samples, now = Date.now()) {
  const from = now - WEEK_MS;
  const inWeek = samples.filter((s) => s.time >= from);
  if (!inWeek.length) return null;
  const segs = discharge(samples, from, now);
  const hours = segs.reduce((s, x) => s + x.hours, 0);
  const perDay = hours >= 12 ? Math.round((segs.reduce((s, x) => s + x.drop, 0) / hours) * 24) : null;
  const week = sessions(samples).filter((x) => x.start >= from && !x.open);
  return {
    perDay,
    charges: week.length,
    avgChargeMinutes: week.length ? Math.round(week.reduce((s, x) => s + x.minutes, 0) / week.length) : null,
    lowest: Math.min(...inWeek.map((s) => s.level)),
    days: (now - inWeek[0].time) / (24 * H),
  };
}

/** The Insights card's two lines, as in the app. tone: "", "red" or "green". */
export function summary(level, d) {
  const rate = d.recent ?? d.usual;
  const hoursLeft = rate != null && rate > 0.05 ? level / rate : null;
  let headline;
  if (hoursLeft == null) headline = "Barely draining";
  else if (hoursLeft >= 48) headline = `About ${Math.round(hoursLeft / 24)} days left`;
  else if (hoursLeft >= 1) headline = `About ${Math.round(hoursLeft)} h left`;
  else headline = "Under an hour left";
  let compare = "Usual pace", tone = "";
  if (d.recent == null || d.usual == null || d.usual <= 0) compare = "Learning its usual pace";
  else if (d.unusual || d.recent > d.usual * 1.3) { compare = `Draining ${Math.round((d.recent / d.usual - 1) * 100)}% faster than usual`; tone = "red"; }
  else if (d.recent < d.usual * 0.7) { compare = "Slower than usual"; tone = "green"; }
  return { headline, compare, tone, hasRate: rate != null };
}
