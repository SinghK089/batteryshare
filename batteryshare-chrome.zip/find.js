// Find My Device over the internet, the same requests the app uses:
//   users/{uid}/commands/{id} { target, from, action: "ring"|"stop", status: "pending"|"ringing"|"stopped"|"failed", createdAt }
import { recentCommands, patchDoc, addToMine, getDoc, session } from "./cloud.js";
import { getSettings } from "./settings.js";
import { note } from "./alerts.js";

export const RING_MS = 45_000;
const MAX_AGE_MS = 2 * 60_000;
const NOTIFICATION = "bs-ring";

// ---------- This computer being rung ----------
let ringing = null; // { id, until, timer }

async function ensureAudio() {
  // One offscreen document: battery reading, plus audio while ringing.
  const has = await chrome.offscreen.hasDocument?.();
  const want = ["BATTERY_STATUS", "AUDIO_PLAYBACK"];
  if (has) {
    const ctx = await chrome.runtime.getContexts?.({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
    if (ctx?.length && ctx[0].documentUrl?.includes("audio=1")) return;
    await chrome.offscreen.closeDocument().catch(() => {});
  }
  await chrome.offscreen.createDocument({
    url: "offscreen.html?audio=1",
    reasons: want,
    justification: "Read this computer's battery, and play a sound when you ring it from your phone.",
  }).catch(() => {});
}

export async function startRinging(commandId, from) {
  if (ringing?.id === commandId) return;
  await stopRinging(null, false);
  const until = Date.now() + RING_MS;
  await chrome.storage.local.set({ ringUntil: until });
  const had = (await chrome.runtime.getContexts?.({ contextTypes: ["OFFSCREEN_DOCUMENT"] }))?.[0]?.documentUrl?.includes("audio=1");
  await ensureAudio();
  if (had) await chrome.runtime.sendMessage({ type: "ringStart", ms: RING_MS }).catch(() => {});
  ringing = { id: commandId, until, timer: setTimeout(() => stopRinging("stopped"), RING_MS) };
  const fromName = from ? (await getDoc(`users/${(await session())?.uid}/devices/${from}`))?.name : null;
  chrome.notifications.create(NOTIFICATION, {
    type: "basic",
    iconUrl: "icons/128.png",
    title: "Find My Device",
    message: `${fromName || "Your other device"} is looking for this computer`,
    buttons: [{ title: "Stop" }],
    requireInteraction: true,
    priority: 2,
    silent: true,
  });
  await patchDoc(`users/${(await session()).uid}/commands/${commandId}`, { status: "ringing" });
  note("RING", "This computer rang", `Rung from ${fromName || "your other device"}`, "Find My Device");
  // Listen for "stop" from the other device more often while ringing.
  pollWhileRinging();
}

export async function stopRinging(status = "stopped", report = true) {
  if (!ringing) return;
  const { id } = ringing;
  clearTimeout(ringing.timer);
  ringing = null;
  await chrome.storage.local.set({ ringUntil: 0 });
  chrome.runtime.sendMessage({ type: "ringStop" }).catch(() => {});
  chrome.notifications.clear(NOTIFICATION);
  // Back to the plain battery reader (Chrome closes audio documents that stay silent).
  setTimeout(async () => {
    if (ringing) return;
    await chrome.offscreen.closeDocument().catch(() => {});
    await chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["BATTERY_STATUS"],
      justification: "Read this computer's battery level to share it with your other devices.",
    }).catch(() => {});
    chrome.runtime.sendMessage({ type: "readBattery" }).catch(() => {});
  }, 800);
  const acc = await session();
  if (report && status && acc) await patchDoc(`users/${acc.uid}/commands/${id}`, { status });
}

async function pollWhileRinging() {
  while (ringing) {
    await new Promise((r) => setTimeout(r, 3000));
    if (!ringing) return;
    await checkCommands();
  }
}

/** Looks for requests to ring (or stop) this computer. Called every 30 s. */
export async function checkCommands(selfId) {
  const settings = await getSettings();
  if (!settings.allowRing) return;
  selfId ??= (await chrome.storage.local.get("deviceId")).deviceId;
  if (!selfId) return;
  const list = await recentCommands(Date.now() - MAX_AGE_MS);
  if (!list) return;
  const { handled = [] } = await chrome.storage.local.get("handled");
  for (const c of list.filter((x) => x.target === selfId).sort((a, b) => a.createdAt - b.createdAt)) {
    if (c.action === "ring" && c.status === "pending" && !handled.includes(c.id)) {
      handled.push(c.id);
      await chrome.storage.local.set({ handled: handled.slice(-30) });
      await startRinging(c.id, c.from);
    } else if (c.action === "stop" && (c.status === "pending" || c.status === "ringing") && ringing?.id === c.id) {
      await stopRinging("stopped");
    }
  }
}

/** Background only: the Stop button on the ringing notification. */
export function listenForStop() {
  chrome.notifications.onButtonClicked.addListener((id) => { if (id === NOTIFICATION) stopRinging("stopped"); });
  chrome.notifications.onClosed.addListener((id, byUser) => { if (id === NOTIFICATION && byUser) stopRinging("stopped"); });
}

// ---------- Ringing another device (from the popup) ----------
export async function ring(targetId) {
  const { deviceId } = await chrome.storage.local.get("deviceId");
  return addToMine("commands", { target: targetId, from: deviceId || "chrome", action: "ring", status: "pending", createdAt: Date.now() });
}
export async function stop(commandId) {
  const acc = await session();
  return acc && patchDoc(`users/${acc.uid}/commands/${commandId}`, { action: "stop" });
}
export async function status(commandId) {
  const acc = await session();
  return acc ? (await getDoc(`users/${acc.uid}/commands/${commandId}`))?.status : null;
}
