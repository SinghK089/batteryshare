// BatteryShare Pro on this computer: the same account-level grants the app uses.
//  - bought in the app (users/{uid}.proPurchased, written by the app)
//  - a tester invite code (users/{uid}.proCode + proCodes/{code} + its redemption)
//  - the free trial (users/{uid}.trialStartedAt + config/app.trialDays)
//  - the store review account
import { session, getDoc } from "./cloud.js";

const DAY = 86_400_000;
const REVIEWERS = ["review@batteryshare.app"];
const CACHE_MS = 60 * 60_000;

/** { pro, source: "purchase"|"code"|"trial"|"review"|null, until } — cached for an hour. */
export async function proStatus(force = false) {
  const acc = await session();
  if (!acc) return { pro: false, source: null, until: 0 };
  const { proCache } = await chrome.storage.local.get("proCache");
  if (!force && proCache && proCache.uid === acc.uid && Date.now() - proCache.at < CACHE_MS) {
    return withExpiry(proCache.status);
  }
  const status = await compute(acc);
  await chrome.storage.local.set({ proCache: { uid: acc.uid, at: Date.now(), status } });
  return status;
}

function withExpiry(s) {
  if (s.pro && s.until && s.until !== Infinity && s.until < Date.now()) return { pro: false, source: null, until: 0 };
  return s;
}

async function compute(acc) {
  if (REVIEWERS.includes(String(acc.email).toLowerCase())) return { pro: true, source: "review", until: 0 };
  const user = await getDoc(`users/${acc.uid}`);
  if (!user) return { pro: false, source: null, until: 0 };
  if (user.proPurchased === true) return { pro: true, source: "purchase", until: 0 };
  const now = Date.now();
  let best = null;
  if (user.proCode) {
    const code = await getDoc(`proCodes/${user.proCode}`);
    const red = await getDoc(`proCodes/${user.proCode}/redemptions/${acc.uid}`);
    if (code?.active === true && red?.at && red.revoked !== true) {
      const until = red.at + (code.days || 30) * DAY;
      if (until > now) best = { pro: true, source: "code", until };
    }
  }
  if (user.trialStartedAt) {
    const config = await getDoc("config/app");
    const days = Math.min(60, Math.max(1, config?.trialDays || 7));
    const until = user.trialStartedAt + days * DAY;
    if (until > now && until > (best?.until || 0)) best = { pro: true, source: "trial", until };
  }
  return best || { pro: false, source: null, until: 0 };
}

export function proLabel(s) {
  if (!s.pro) return "Free plan";
  const date = s.until ? new Date(s.until).toLocaleDateString([], { day: "numeric", month: "short" }) : "";
  switch (s.source) {
    case "purchase": return "Pro";
    case "review": return "Pro (review account)";
    case "code": return `Pro (tester) until ${date}`;
    case "trial": return `Pro trial until ${date}`;
    default: return "Pro";
  }
}
