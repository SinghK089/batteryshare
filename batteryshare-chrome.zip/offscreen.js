// The background worker can't read the battery, so this hidden page does and reports back.
import { read, watch } from "./battery.js";

const send = async () => chrome.runtime.sendMessage({ type: "battery", battery: await read() }).catch(() => {});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === "readBattery") send();
});

watch(send);
send();
