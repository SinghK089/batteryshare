// The background worker can't read the battery or play sound, so this hidden page does.
import { read, watch } from "./battery.js";

const send = async () => chrome.runtime.sendMessage({ type: "battery", battery: await read() }).catch(() => {});

// Find My Device: a loud, rising two-tone chime, repeated until stopped (or the time is up).
let audio = null;
function ringStart(ms) {
  ringStop();
  const ctx = new AudioContext();
  const master = ctx.createGain();
  master.gain.value = 0.9;
  master.connect(ctx.destination);
  const beep = (t, freq) => {
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = "triangle";
    o.frequency.setValueAtTime(freq, t);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(1, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.28);
    o.connect(g).connect(master);
    o.start(t);
    o.stop(t + 0.3);
  };
  const end = ctx.currentTime + ms / 1000;
  let t = ctx.currentTime + 0.05;
  const schedule = () => {
    while (t < ctx.currentTime + 2 && t < end) {
      beep(t, 880); beep(t + 0.32, 1175); beep(t + 0.64, 1568);
      t += 1.4;
    }
  };
  schedule();
  audio = { ctx, timer: setInterval(schedule, 500), stop: setTimeout(ringStop, ms) };
}
function ringStop() {
  if (!audio) return;
  clearInterval(audio.timer);
  clearTimeout(audio.stop);
  audio.ctx.close().catch(() => {});
  audio = null;
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === "readBattery") send();
  if (msg?.type === "ringStart") ringStart(msg.ms || 45000);
  if (msg?.type === "ringStop") ringStop();
});

watch(send);
send();
// Opened to ring: start right away (the "ringStart" message may arrive before this page loads).
chrome.storage.local.get("ringUntil").then(({ ringUntil }) => {
  if (ringUntil && ringUntil > Date.now() + 1000 && !audio) ringStart(ringUntil - Date.now());
});
